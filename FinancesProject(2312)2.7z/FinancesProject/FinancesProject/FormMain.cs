﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinancesProject
{
    public partial class FormMain : Form
    {
        public int location_x_wallets = -105;
        public int location_y_wallets = 10;
        public int location_x_writes = -250;
        public int location_y_writes = 10;
        public static int user_id;
        static string relativePath = @"..\..\UsersDB.mdf";
        string connectionString = $@"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog = UsersDB.mdf;AttachDbFilename={Path.Combine(AppDomain.CurrentDomain.BaseDirectory, relativePath)};Integrated Security=True";

        public void OpenWindow(Panel panel)
        {
            panelWallets.Visible = false;
            panelWallets.Enabled = false;
            panelStat.Visible = false;
            panelStat.Enabled = false;
            panelMain.Visible = false;
            panelMain.Enabled = false;
            panelProfile.Enabled = false;
            panelProfile.Visible = false;
            panel.Visible = true;
            panel.Enabled = true;
        }

        public FormMain(int id)
        {
            InitializeComponent();
            user_id = id;
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    Debug.WriteLine("Success connection");
                    OpenWindow(panelMain);
                    Debug.WriteLine("Main = " + user_id);
                }
                catch (SqlException ex)
                {
                    Debug.WriteLine(ex.Message);
                }
            }
            Show_Writes();
        }

        public void Create_Wallet(string wallet_title, string balance, int i)
        {
            if(i == 0 || i == 4 || i == 8)
            {
                location_x_wallets = -105;
                if(i == 4 || i == 8)
                {
                    location_y_wallets += 105;
                }

            }
            //location_y_wallets += 105;
            location_x_wallets += 130;
            
            GroupBox groupBox = new GroupBox();
            panelWalletsElements.Controls.Add(groupBox);

            groupBox.Text = wallet_title;

            groupBox.Location = new Point(location_x_wallets, location_y_wallets);

            groupBox.Size = new Size(125, 100);

            System.Windows.Forms.Label labelBalance = new System.Windows.Forms.Label();
            groupBox.Controls.Add(labelBalance);
            labelBalance.Location = new Point(5, 25);
            labelBalance.Text = balance + " ₽";
            groupBox.Visible = true;

        }

        public void Show_Wallets()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                string sql_wallet = "SELECT Name, Amount FROM Wallets WHERE User_id = @user_id";

                SqlCommand select_wallet = new SqlCommand(sql_wallet, conn);

                select_wallet.Parameters.AddWithValue("@user_id", user_id);

                SqlDataReader reader = select_wallet.ExecuteReader();

                int i = 0;

                while (reader.Read())
                {
                    Create_Wallet(reader["Name"].ToString(), reader["Amount"].ToString(), i);
                    i++;
                }

                reader.Close();

                conn.Close();
            }
        }

        public void Create_Writes(string amount, string category_id, string type_id, string date, string wallet_id, int i)
        {
            if(i == 0)
            {
                location_x_writes = -250;
                location_y_writes = 10;
            }
            else if (i == 2 || i == 4 || i == 6 || i == 8)
            {
                location_x_writes = -250;
                location_y_writes += 90;

            }
            location_x_writes += 270;

            GroupBox groupBox = new GroupBox();
            panelWrites.Controls.Add(groupBox);

            groupBox.Location = new Point(location_x_writes, location_y_writes);

            groupBox.Size = new Size(260, 100);

            System.Windows.Forms.Label labelAmount = new System.Windows.Forms.Label();
            System.Windows.Forms.Label labelCategory = new System.Windows.Forms.Label();
            System.Windows.Forms.Label labelType = new System.Windows.Forms.Label();
            System.Windows.Forms.Label labelWallet = new System.Windows.Forms.Label();
            System.Windows.Forms.Label labelDate= new System.Windows.Forms.Label();
            groupBox.Controls.Add(labelAmount);
            labelAmount.Location = new Point(20, 20);
            labelAmount.Text = amount + " ₽";
            groupBox.Controls.Add(labelCategory);
            labelCategory.Location = new Point(20, 45);
            labelCategory.Text = "Категория " + category_id;
            groupBox.Controls.Add(labelType);
            labelType.Location = new Point(20, 70);
            labelType.Text = "Тип " + type_id;
            groupBox.Controls.Add(labelWallet);
            labelWallet.Location = new Point(160, 45);
            labelWallet.Text = "Кошелек " + wallet_id;
            groupBox.Controls.Add(labelDate);
            labelDate.Location = new Point(160, 70);
            labelDate.Text = "Дата " + date;

            groupBox.Visible = true;
        }

        public void Show_Writes()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                string sql_wallet = "SELECT Amount, Category_id, Type_id, Date, Wallet_id FROM Transactions WHERE User_id = @user_id";

                SqlCommand select_wallet = new SqlCommand(sql_wallet, conn);

                select_wallet.Parameters.AddWithValue("@user_id", user_id);

                SqlDataReader reader = select_wallet.ExecuteReader();

                int i = 0;

                while (reader.Read())
                {
                    Create_Writes(reader["Amount"].ToString(), reader["Category_id"].ToString(), reader["Type_id"].ToString(), reader["Date"].ToString(), reader["Wallet_id"].ToString(), i);
                    i++;
                }

                reader.Close();

                conn.Close();
            }
        }

        private void buttonProfile_Click(object sender, EventArgs e)
        {
            OpenWindow(panelProfile);
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void buttonMain_Click(object sender, EventArgs e)
        {
            OpenWindow(panelMain);
            panelWrites.Controls.Clear();
            Show_Writes();
            location_x_writes = -250;
            location_y_writes = 10;

        }

        private void buttonStat_Click(object sender, EventArgs e)
        {
            OpenWindow(panelStat);
        }

        private void buttonWallets_Click(object sender, EventArgs e)
        {
            OpenWindow(panelWallets);
            panelWalletsElements.Controls.Clear();
            Show_Wallets();
            location_x_wallets = -105;
            location_y_wallets = 10;
        }

        private void panelMain_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panelExpenses_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Expense1_Enter(object sender, EventArgs e)
        {

        }

        private void buttonAddExpense_Click(object sender, EventArgs e)
        {

        }

        private void panelIncomes_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Income1_Enter(object sender, EventArgs e)
        {

        }

        private void buttonAddIncome_Click(object sender, EventArgs e)
        {

        }

        private void panelWallets_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Wallet1_Enter(object sender, EventArgs e)
        {

        }

        private void panelStat_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void buttonAddTransaction_Click(object sender, EventArgs e)
        {
            FormData f3 = new FormData(user_id);
            this.Hide();
            f3.ShowDialog();
            this.Close();
        }

        private void buttonAddCategory_Click(object sender, EventArgs e)
        {
            FormCategory f4 = new FormCategory(user_id);
            this.Hide();
            f4.ShowDialog();
            this.Close();
        }

        private void buttonAddWallet_Click(object sender, EventArgs e)
        {
            FormWallet f5 = new FormWallet(user_id);
            this.Hide();
            f5.ShowDialog();
            this.Close();
        }
    }
}
