﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinancesProject
{
    public partial class FormWallet : Form
    {
        public static int user_id;
        static string relativePath = @"..\..\UsersDB.mdf";
        string connectionString = $@"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog = UsersDB.mdf;AttachDbFilename={Path.Combine(AppDomain.CurrentDomain.BaseDirectory, relativePath)};Integrated Security=True";

        public FormWallet(int id)
        {
            InitializeComponent();
            user_id = id;
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    Debug.WriteLine(id);
                    conn.Close();
                }
                Debug.WriteLine("Success connection");
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
            }
        }

        public void CreateWallet(string name, string balance)
        {
            using(SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                string sql = "INSERT INTO Wallets(Name, Amount, User_id) " +
                    "VALUES(@name, @balance, @user_id)";

                SqlCommand create = new SqlCommand(sql, conn);

                create.Parameters.AddWithValue("@name", name);
                create.Parameters.AddWithValue("@balance", balance);
                create.Parameters.AddWithValue("@user_id", user_id);

                int row = create.ExecuteNonQuery();

                conn.Close();

                MessageBox.Show("Успешно создан кошелёк", "Успешно", MessageBoxButtons.OK, MessageBoxIcon.Information);
                FormMain f2 = new FormMain(user_id);
                this.Hide();
                f2.ShowDialog();
                this.Close();
            }
        }

        private void FormWallet_Load(object sender, EventArgs e)
        {

        }

        private void buttonAddWallet_Click(object sender, EventArgs e)
        {
            CreateWallet(textNameOfWallet.Text, textBalanceOfWallet.Text);
        }

        private void buttonBackWallet_Click(object sender, EventArgs e)
        {
            FormMain f2 = new FormMain(user_id);
            this.Hide();
            f2.ShowDialog();
            this.Close();
        }
    }
}
