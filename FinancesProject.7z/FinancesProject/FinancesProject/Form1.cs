﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Diagnostics.Eventing.Reader;

namespace FinancesProject
{
    public partial class Form1 : Form
    {
        public void OpenWindow(Panel panel)
        {
            panelExpenses.Visible = false;
            panelExpenses.Enabled = false;
            panelIncomes.Visible = false;
            panelIncomes.Enabled = false;
            panelWallets.Visible = false;
            panelWallets.Enabled = false;
            panelStat.Visible = false;
            panelStat.Enabled = false;
            panelMain.Visible = false;
            panelMain.Enabled = false;
            panelAuthorization.Enabled = false;
            panelAuthorization.Visible = false;
            panelRegistration.Enabled = false;
            panelRegistration.Visible = false;
            panelProfile.Enabled = false;
            panelProfile.Visible = false;
            panel.Visible = true;
            panel.Enabled = true;
        }

        public void Authorization(TextBox login, TextBox password)
        {
            if(login.Text == "admin" && password.Text == "admin")
            {
                OpenWindow(panelMain);
            }
        }

        public Form1()
        {
            InitializeComponent();
            //OpenWindow(panelMain);
            OpenWindow(panelAuthorization);
            string connectionString = (@"Data Source=(localdb)\MSSQLLocalDB;AttachDbFilename=C:\Users\Степан\source\repos\FinancesProject\FinancesProject\UsersDB.mdf;Initial Catalog=UsersDB;Integrated Security=True");
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    Debug.WriteLine("Success connection");
                }
                catch (SqlException ex)
                {
                    Debug.WriteLine(ex.Message);
                }
            }
        }

        private void buttonProfile_Click(object sender, EventArgs e)
        {
            OpenWindow(panelProfile);
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void buttonMain_Click(object sender, EventArgs e)
        {
            OpenWindow(panelMain);
        }

        private void buttonExpenses_Click(object sender, EventArgs e)
        {
            OpenWindow(panelExpenses);
        }

        private void buttonIncomes_Click(object sender, EventArgs e)
        {
            OpenWindow(panelIncomes);
        }

        private void buttonStat_Click(object sender, EventArgs e)
        {
            OpenWindow(panelStat);
        }

        private void buttonWallets_Click(object sender, EventArgs e)
        {
            OpenWindow(panelWallets);
        }

        private void panelMain_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panelExpenses_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Expense1_Enter(object sender, EventArgs e)
        {

        }

        private void buttonAddExpense_Click(object sender, EventArgs e)
        {

        }

        private void panelIncomes_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Income1_Enter(object sender, EventArgs e)
        {

        }

        private void buttonAddIncome_Click(object sender, EventArgs e)
        {

        }

        private void panelWallets_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Wallet1_Enter(object sender, EventArgs e)
        {

        }

        private void panelStat_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void buttonReg_Click(object sender, EventArgs e)
        {

        }

        private void buttonAuthPanel_Click(object sender, EventArgs e)
        {
            OpenWindow(panelAuthorization);
            textLogin.Text = string.Empty;
            textPassword.Text = string.Empty;
        }

        private void panelRegistration_Paint(object sender, PaintEventArgs e)
        {

        }

        private void buttonRegPanel_Click(object sender, EventArgs e)
        {
            OpenWindow(panelRegistration);
            textLoginReg.Text = string.Empty;
            textPasswordReg.Text = string.Empty;
            textPasswordRegRep.Text = string.Empty;
        }

        private void textPassword_TextChanged(object sender, EventArgs e)
        {

        }

        private void buttonAuth_Click(object sender, EventArgs e)
        {
            Authorization(textLogin, textPassword);
        }
    }
}
