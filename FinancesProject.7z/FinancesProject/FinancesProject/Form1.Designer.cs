﻿namespace FinancesProject
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonExpenses = new System.Windows.Forms.Button();
            this.buttonIncomes = new System.Windows.Forms.Button();
            this.buttonStat = new System.Windows.Forms.Button();
            this.buttonWallets = new System.Windows.Forms.Button();
            this.buttonProfile = new System.Windows.Forms.Button();
            this.buttonExit = new System.Windows.Forms.Button();
            this.buttonMain = new System.Windows.Forms.Button();
            this.panelMain = new System.Windows.Forms.Panel();
            this.Writes = new System.Windows.Forms.GroupBox();
            this.labelDate = new System.Windows.Forms.Label();
            this.labelWallet = new System.Windows.Forms.Label();
            this.labelType = new System.Windows.Forms.Label();
            this.labelCategory = new System.Windows.Forms.Label();
            this.labelAmount = new System.Windows.Forms.Label();
            this.buttonCreateIncome = new System.Windows.Forms.Button();
            this.buttonCreateExspense = new System.Windows.Forms.Button();
            this.labelMain = new System.Windows.Forms.Label();
            this.panelExpenses = new System.Windows.Forms.Panel();
            this.Expense1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.buttonAddExpense = new System.Windows.Forms.Button();
            this.labelExpenses = new System.Windows.Forms.Label();
            this.panelStat = new System.Windows.Forms.Panel();
            this.labelStat = new System.Windows.Forms.Label();
            this.panelIncomes = new System.Windows.Forms.Panel();
            this.Income1 = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.buttonAddIncome = new System.Windows.Forms.Button();
            this.labelIncome = new System.Windows.Forms.Label();
            this.panelWallets = new System.Windows.Forms.Panel();
            this.Wallet1 = new System.Windows.Forms.GroupBox();
            this.labelWalletAmount = new System.Windows.Forms.Label();
            this.labelWallets = new System.Windows.Forms.Label();
            this.panelAuthorization = new System.Windows.Forms.Panel();
            this.labelAuthorization = new System.Windows.Forms.Label();
            this.textLogin = new System.Windows.Forms.TextBox();
            this.textPassword = new System.Windows.Forms.TextBox();
            this.buttonAuth = new System.Windows.Forms.Button();
            this.buttonRegPanel = new System.Windows.Forms.Button();
            this.panelRegistration = new System.Windows.Forms.Panel();
            this.buttonAuthPanel = new System.Windows.Forms.Button();
            this.buttonReg = new System.Windows.Forms.Button();
            this.textPasswordReg = new System.Windows.Forms.TextBox();
            this.textLoginReg = new System.Windows.Forms.TextBox();
            this.labelReg = new System.Windows.Forms.Label();
            this.textPasswordRegRep = new System.Windows.Forms.TextBox();
            this.panelProfile = new System.Windows.Forms.Panel();
            this.labelProfile = new System.Windows.Forms.Label();
            this.labelProfileName = new System.Windows.Forms.Label();
            this.panelMain.SuspendLayout();
            this.Writes.SuspendLayout();
            this.panelExpenses.SuspendLayout();
            this.Expense1.SuspendLayout();
            this.panelStat.SuspendLayout();
            this.panelIncomes.SuspendLayout();
            this.Income1.SuspendLayout();
            this.panelWallets.SuspendLayout();
            this.Wallet1.SuspendLayout();
            this.panelAuthorization.SuspendLayout();
            this.panelRegistration.SuspendLayout();
            this.panelProfile.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonExpenses
            // 
            this.buttonExpenses.Location = new System.Drawing.Point(12, 144);
            this.buttonExpenses.Name = "buttonExpenses";
            this.buttonExpenses.Size = new System.Drawing.Size(100, 55);
            this.buttonExpenses.TabIndex = 0;
            this.buttonExpenses.Text = "Расходы";
            this.buttonExpenses.UseVisualStyleBackColor = true;
            this.buttonExpenses.Click += new System.EventHandler(this.buttonExpenses_Click);
            // 
            // buttonIncomes
            // 
            this.buttonIncomes.Location = new System.Drawing.Point(12, 205);
            this.buttonIncomes.Name = "buttonIncomes";
            this.buttonIncomes.Size = new System.Drawing.Size(100, 55);
            this.buttonIncomes.TabIndex = 1;
            this.buttonIncomes.Text = "Доходы";
            this.buttonIncomes.UseVisualStyleBackColor = true;
            this.buttonIncomes.Click += new System.EventHandler(this.buttonIncomes_Click);
            // 
            // buttonStat
            // 
            this.buttonStat.Location = new System.Drawing.Point(12, 266);
            this.buttonStat.Name = "buttonStat";
            this.buttonStat.Size = new System.Drawing.Size(100, 55);
            this.buttonStat.TabIndex = 2;
            this.buttonStat.Text = "Статистика";
            this.buttonStat.UseVisualStyleBackColor = true;
            this.buttonStat.Click += new System.EventHandler(this.buttonStat_Click);
            // 
            // buttonWallets
            // 
            this.buttonWallets.Location = new System.Drawing.Point(12, 327);
            this.buttonWallets.Name = "buttonWallets";
            this.buttonWallets.Size = new System.Drawing.Size(100, 55);
            this.buttonWallets.TabIndex = 3;
            this.buttonWallets.Text = "Кошельки";
            this.buttonWallets.UseVisualStyleBackColor = true;
            this.buttonWallets.Click += new System.EventHandler(this.buttonWallets_Click);
            // 
            // buttonProfile
            // 
            this.buttonProfile.Location = new System.Drawing.Point(713, 12);
            this.buttonProfile.Name = "buttonProfile";
            this.buttonProfile.Size = new System.Drawing.Size(75, 23);
            this.buttonProfile.TabIndex = 4;
            this.buttonProfile.Text = "Профиль";
            this.buttonProfile.UseVisualStyleBackColor = true;
            this.buttonProfile.Click += new System.EventHandler(this.buttonProfile_Click);
            // 
            // buttonExit
            // 
            this.buttonExit.Location = new System.Drawing.Point(713, 415);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(75, 23);
            this.buttonExit.TabIndex = 5;
            this.buttonExit.Text = "Выйти";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // buttonMain
            // 
            this.buttonMain.Location = new System.Drawing.Point(12, 83);
            this.buttonMain.Name = "buttonMain";
            this.buttonMain.Size = new System.Drawing.Size(100, 55);
            this.buttonMain.TabIndex = 6;
            this.buttonMain.Text = "Главная";
            this.buttonMain.UseVisualStyleBackColor = true;
            this.buttonMain.Click += new System.EventHandler(this.buttonMain_Click);
            // 
            // panelMain
            // 
            this.panelMain.Controls.Add(this.Writes);
            this.panelMain.Controls.Add(this.buttonCreateIncome);
            this.panelMain.Controls.Add(this.buttonCreateExspense);
            this.panelMain.Controls.Add(this.labelMain);
            this.panelMain.Enabled = false;
            this.panelMain.Location = new System.Drawing.Point(118, 41);
            this.panelMain.Name = "panelMain";
            this.panelMain.Size = new System.Drawing.Size(605, 368);
            this.panelMain.TabIndex = 7;
            this.panelMain.Visible = false;
            this.panelMain.Paint += new System.Windows.Forms.PaintEventHandler(this.panelMain_Paint);
            // 
            // Writes
            // 
            this.Writes.Controls.Add(this.labelDate);
            this.Writes.Controls.Add(this.labelWallet);
            this.Writes.Controls.Add(this.labelType);
            this.Writes.Controls.Add(this.labelCategory);
            this.Writes.Controls.Add(this.labelAmount);
            this.Writes.Location = new System.Drawing.Point(165, 58);
            this.Writes.Name = "Writes";
            this.Writes.Size = new System.Drawing.Size(259, 100);
            this.Writes.TabIndex = 3;
            this.Writes.TabStop = false;
            this.Writes.Text = "Запись 1";
            // 
            // labelDate
            // 
            this.labelDate.AutoSize = true;
            this.labelDate.Location = new System.Drawing.Point(179, 70);
            this.labelDate.Name = "labelDate";
            this.labelDate.Size = new System.Drawing.Size(33, 13);
            this.labelDate.TabIndex = 4;
            this.labelDate.Text = "Дата";
            // 
            // labelWallet
            // 
            this.labelWallet.AutoSize = true;
            this.labelWallet.Location = new System.Drawing.Point(179, 45);
            this.labelWallet.Name = "labelWallet";
            this.labelWallet.Size = new System.Drawing.Size(52, 13);
            this.labelWallet.TabIndex = 3;
            this.labelWallet.Text = "Кошелек";
            // 
            // labelType
            // 
            this.labelType.AutoSize = true;
            this.labelType.Location = new System.Drawing.Point(23, 70);
            this.labelType.Name = "labelType";
            this.labelType.Size = new System.Drawing.Size(26, 13);
            this.labelType.TabIndex = 2;
            this.labelType.Text = "Тип";
            // 
            // labelCategory
            // 
            this.labelCategory.AutoSize = true;
            this.labelCategory.Location = new System.Drawing.Point(23, 45);
            this.labelCategory.Name = "labelCategory";
            this.labelCategory.Size = new System.Drawing.Size(60, 13);
            this.labelCategory.TabIndex = 1;
            this.labelCategory.Text = "Категория";
            // 
            // labelAmount
            // 
            this.labelAmount.AutoSize = true;
            this.labelAmount.Location = new System.Drawing.Point(23, 20);
            this.labelAmount.Name = "labelAmount";
            this.labelAmount.Size = new System.Drawing.Size(41, 13);
            this.labelAmount.TabIndex = 0;
            this.labelAmount.Text = "Сумма";
            // 
            // buttonCreateIncome
            // 
            this.buttonCreateIncome.Location = new System.Drawing.Point(298, 317);
            this.buttonCreateIncome.Name = "buttonCreateIncome";
            this.buttonCreateIncome.Size = new System.Drawing.Size(104, 48);
            this.buttonCreateIncome.TabIndex = 2;
            this.buttonCreateIncome.Text = "Добавить доход";
            this.buttonCreateIncome.UseVisualStyleBackColor = true;
            // 
            // buttonCreateExspense
            // 
            this.buttonCreateExspense.Location = new System.Drawing.Point(188, 317);
            this.buttonCreateExspense.Name = "buttonCreateExspense";
            this.buttonCreateExspense.Size = new System.Drawing.Size(104, 48);
            this.buttonCreateExspense.TabIndex = 1;
            this.buttonCreateExspense.Text = "Добавить трату";
            this.buttonCreateExspense.UseVisualStyleBackColor = true;
            // 
            // labelMain
            // 
            this.labelMain.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelMain.Location = new System.Drawing.Point(217, 11);
            this.labelMain.Name = "labelMain";
            this.labelMain.Size = new System.Drawing.Size(153, 41);
            this.labelMain.TabIndex = 0;
            this.labelMain.Text = "Главная";
            // 
            // panelExpenses
            // 
            this.panelExpenses.Controls.Add(this.Expense1);
            this.panelExpenses.Controls.Add(this.buttonAddExpense);
            this.panelExpenses.Controls.Add(this.labelExpenses);
            this.panelExpenses.Enabled = false;
            this.panelExpenses.Location = new System.Drawing.Point(118, 41);
            this.panelExpenses.Name = "panelExpenses";
            this.panelExpenses.Size = new System.Drawing.Size(605, 368);
            this.panelExpenses.TabIndex = 8;
            this.panelExpenses.Visible = false;
            this.panelExpenses.Paint += new System.Windows.Forms.PaintEventHandler(this.panelExpenses_Paint);
            // 
            // Expense1
            // 
            this.Expense1.Controls.Add(this.label1);
            this.Expense1.Controls.Add(this.label2);
            this.Expense1.Controls.Add(this.label3);
            this.Expense1.Controls.Add(this.label4);
            this.Expense1.Controls.Add(this.label5);
            this.Expense1.Location = new System.Drawing.Point(165, 58);
            this.Expense1.Name = "Expense1";
            this.Expense1.Size = new System.Drawing.Size(259, 100);
            this.Expense1.TabIndex = 3;
            this.Expense1.TabStop = false;
            this.Expense1.Text = "Запись 1";
            this.Expense1.Enter += new System.EventHandler(this.Expense1_Enter);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(179, 70);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(33, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Дата";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(179, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Кошелек";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(23, 70);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(26, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Тип";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(23, 45);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Категория";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(23, 20);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "Сумма";
            // 
            // buttonAddExpense
            // 
            this.buttonAddExpense.Location = new System.Drawing.Point(240, 317);
            this.buttonAddExpense.Name = "buttonAddExpense";
            this.buttonAddExpense.Size = new System.Drawing.Size(104, 48);
            this.buttonAddExpense.TabIndex = 1;
            this.buttonAddExpense.Text = "Добавить трату";
            this.buttonAddExpense.UseVisualStyleBackColor = true;
            this.buttonAddExpense.Click += new System.EventHandler(this.buttonAddExpense_Click);
            // 
            // labelExpenses
            // 
            this.labelExpenses.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelExpenses.Location = new System.Drawing.Point(217, 11);
            this.labelExpenses.Name = "labelExpenses";
            this.labelExpenses.Size = new System.Drawing.Size(160, 41);
            this.labelExpenses.TabIndex = 0;
            this.labelExpenses.Text = "Расходы";
            // 
            // panelStat
            // 
            this.panelStat.Controls.Add(this.labelStat);
            this.panelStat.Enabled = false;
            this.panelStat.Location = new System.Drawing.Point(118, 41);
            this.panelStat.Name = "panelStat";
            this.panelStat.Size = new System.Drawing.Size(605, 368);
            this.panelStat.TabIndex = 10;
            this.panelStat.Visible = false;
            this.panelStat.Paint += new System.Windows.Forms.PaintEventHandler(this.panelStat_Paint);
            // 
            // labelStat
            // 
            this.labelStat.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelStat.Location = new System.Drawing.Point(195, 11);
            this.labelStat.Name = "labelStat";
            this.labelStat.Size = new System.Drawing.Size(207, 41);
            this.labelStat.TabIndex = 0;
            this.labelStat.Text = "Статистика";
            // 
            // panelIncomes
            // 
            this.panelIncomes.Controls.Add(this.Income1);
            this.panelIncomes.Controls.Add(this.buttonAddIncome);
            this.panelIncomes.Controls.Add(this.labelIncome);
            this.panelIncomes.Enabled = false;
            this.panelIncomes.Location = new System.Drawing.Point(118, 41);
            this.panelIncomes.Name = "panelIncomes";
            this.panelIncomes.Size = new System.Drawing.Size(605, 368);
            this.panelIncomes.TabIndex = 11;
            this.panelIncomes.Visible = false;
            this.panelIncomes.Paint += new System.Windows.Forms.PaintEventHandler(this.panelIncomes_Paint);
            // 
            // Income1
            // 
            this.Income1.Controls.Add(this.label6);
            this.Income1.Controls.Add(this.label7);
            this.Income1.Controls.Add(this.label8);
            this.Income1.Controls.Add(this.label9);
            this.Income1.Controls.Add(this.label11);
            this.Income1.Location = new System.Drawing.Point(165, 58);
            this.Income1.Name = "Income1";
            this.Income1.Size = new System.Drawing.Size(259, 100);
            this.Income1.TabIndex = 3;
            this.Income1.TabStop = false;
            this.Income1.Text = "Запись 1";
            this.Income1.Enter += new System.EventHandler(this.Income1_Enter);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(179, 70);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(33, 13);
            this.label6.TabIndex = 4;
            this.label6.Text = "Дата";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(179, 45);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(52, 13);
            this.label7.TabIndex = 3;
            this.label7.Text = "Кошелек";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(23, 70);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(26, 13);
            this.label8.TabIndex = 2;
            this.label8.Text = "Тип";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(23, 45);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(60, 13);
            this.label9.TabIndex = 1;
            this.label9.Text = "Категория";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(23, 20);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(41, 13);
            this.label11.TabIndex = 0;
            this.label11.Text = "Сумма";
            // 
            // buttonAddIncome
            // 
            this.buttonAddIncome.Location = new System.Drawing.Point(240, 317);
            this.buttonAddIncome.Name = "buttonAddIncome";
            this.buttonAddIncome.Size = new System.Drawing.Size(104, 48);
            this.buttonAddIncome.TabIndex = 1;
            this.buttonAddIncome.Text = "Добавить доход";
            this.buttonAddIncome.UseVisualStyleBackColor = true;
            this.buttonAddIncome.Click += new System.EventHandler(this.buttonAddIncome_Click);
            // 
            // labelIncome
            // 
            this.labelIncome.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelIncome.Location = new System.Drawing.Point(217, 11);
            this.labelIncome.Name = "labelIncome";
            this.labelIncome.Size = new System.Drawing.Size(160, 41);
            this.labelIncome.TabIndex = 0;
            this.labelIncome.Text = "Доходы";
            // 
            // panelWallets
            // 
            this.panelWallets.Controls.Add(this.Wallet1);
            this.panelWallets.Controls.Add(this.labelWallets);
            this.panelWallets.Enabled = false;
            this.panelWallets.Location = new System.Drawing.Point(118, 41);
            this.panelWallets.Name = "panelWallets";
            this.panelWallets.Size = new System.Drawing.Size(605, 368);
            this.panelWallets.TabIndex = 12;
            this.panelWallets.Visible = false;
            this.panelWallets.Paint += new System.Windows.Forms.PaintEventHandler(this.panelWallets_Paint);
            // 
            // Wallet1
            // 
            this.Wallet1.Controls.Add(this.labelWalletAmount);
            this.Wallet1.Location = new System.Drawing.Point(29, 58);
            this.Wallet1.Name = "Wallet1";
            this.Wallet1.Size = new System.Drawing.Size(200, 100);
            this.Wallet1.TabIndex = 1;
            this.Wallet1.TabStop = false;
            this.Wallet1.Text = "Кошелек 1";
            this.Wallet1.Enter += new System.EventHandler(this.Wallet1_Enter);
            // 
            // labelWalletAmount
            // 
            this.labelWalletAmount.AutoSize = true;
            this.labelWalletAmount.Location = new System.Drawing.Point(6, 26);
            this.labelWalletAmount.Name = "labelWalletAmount";
            this.labelWalletAmount.Size = new System.Drawing.Size(44, 13);
            this.labelWalletAmount.TabIndex = 0;
            this.labelWalletAmount.Text = "Баланс";
            // 
            // labelWallets
            // 
            this.labelWallets.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelWallets.Location = new System.Drawing.Point(215, 11);
            this.labelWallets.Name = "labelWallets";
            this.labelWallets.Size = new System.Drawing.Size(181, 41);
            this.labelWallets.TabIndex = 0;
            this.labelWallets.Text = "Кошельки";
            // 
            // panelAuthorization
            // 
            this.panelAuthorization.Controls.Add(this.buttonAuth);
            this.panelAuthorization.Controls.Add(this.buttonRegPanel);
            this.panelAuthorization.Controls.Add(this.textPassword);
            this.panelAuthorization.Controls.Add(this.textLogin);
            this.panelAuthorization.Controls.Add(this.labelAuthorization);
            this.panelAuthorization.Location = new System.Drawing.Point(12, 12);
            this.panelAuthorization.Name = "panelAuthorization";
            this.panelAuthorization.Size = new System.Drawing.Size(775, 426);
            this.panelAuthorization.TabIndex = 13;
            // 
            // labelAuthorization
            // 
            this.labelAuthorization.AutoSize = true;
            this.labelAuthorization.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelAuthorization.Location = new System.Drawing.Point(320, 29);
            this.labelAuthorization.Name = "labelAuthorization";
            this.labelAuthorization.Size = new System.Drawing.Size(135, 25);
            this.labelAuthorization.TabIndex = 0;
            this.labelAuthorization.Text = "Авторизация";
            // 
            // textLogin
            // 
            this.textLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textLogin.Location = new System.Drawing.Point(286, 106);
            this.textLogin.Name = "textLogin";
            this.textLogin.Size = new System.Drawing.Size(205, 27);
            this.textLogin.TabIndex = 1;
            // 
            // textPassword
            // 
            this.textPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textPassword.Location = new System.Drawing.Point(286, 173);
            this.textPassword.Name = "textPassword";
            this.textPassword.Size = new System.Drawing.Size(205, 27);
            this.textPassword.TabIndex = 2;
            this.textPassword.UseSystemPasswordChar = true;
            this.textPassword.TextChanged += new System.EventHandler(this.textPassword_TextChanged);
            // 
            // buttonAuth
            // 
            this.buttonAuth.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonAuth.Location = new System.Drawing.Point(346, 228);
            this.buttonAuth.Name = "buttonAuth";
            this.buttonAuth.Size = new System.Drawing.Size(95, 44);
            this.buttonAuth.TabIndex = 3;
            this.buttonAuth.Text = "Войти";
            this.buttonAuth.UseVisualStyleBackColor = true;
            this.buttonAuth.Click += new System.EventHandler(this.buttonAuth_Click);
            // 
            // buttonRegPanel
            // 
            this.buttonRegPanel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonRegPanel.Location = new System.Drawing.Point(301, 309);
            this.buttonRegPanel.Name = "buttonRegPanel";
            this.buttonRegPanel.Size = new System.Drawing.Size(190, 61);
            this.buttonRegPanel.TabIndex = 4;
            this.buttonRegPanel.Text = "Нет аккаунта? Зарегистрироваться";
            this.buttonRegPanel.UseVisualStyleBackColor = true;
            this.buttonRegPanel.Click += new System.EventHandler(this.buttonRegPanel_Click);
            // 
            // panelRegistration
            // 
            this.panelRegistration.Controls.Add(this.textPasswordRegRep);
            this.panelRegistration.Controls.Add(this.buttonAuthPanel);
            this.panelRegistration.Controls.Add(this.buttonReg);
            this.panelRegistration.Controls.Add(this.textPasswordReg);
            this.panelRegistration.Controls.Add(this.textLoginReg);
            this.panelRegistration.Controls.Add(this.labelReg);
            this.panelRegistration.Enabled = false;
            this.panelRegistration.Location = new System.Drawing.Point(12, 12);
            this.panelRegistration.Name = "panelRegistration";
            this.panelRegistration.Size = new System.Drawing.Size(775, 426);
            this.panelRegistration.TabIndex = 14;
            this.panelRegistration.Visible = false;
            this.panelRegistration.Paint += new System.Windows.Forms.PaintEventHandler(this.panelRegistration_Paint);
            // 
            // buttonAuthPanel
            // 
            this.buttonAuthPanel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonAuthPanel.Location = new System.Drawing.Point(342, 315);
            this.buttonAuthPanel.Name = "buttonAuthPanel";
            this.buttonAuthPanel.Size = new System.Drawing.Size(107, 49);
            this.buttonAuthPanel.TabIndex = 4;
            this.buttonAuthPanel.Text = "Авторизоваться";
            this.buttonAuthPanel.UseVisualStyleBackColor = true;
            this.buttonAuthPanel.Click += new System.EventHandler(this.buttonAuthPanel_Click);
            // 
            // buttonReg
            // 
            this.buttonReg.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonReg.Location = new System.Drawing.Point(329, 254);
            this.buttonReg.Name = "buttonReg";
            this.buttonReg.Size = new System.Drawing.Size(130, 44);
            this.buttonReg.TabIndex = 3;
            this.buttonReg.Text = "Зарегистрироваться";
            this.buttonReg.UseVisualStyleBackColor = true;
            this.buttonReg.Click += new System.EventHandler(this.buttonReg_Click);
            // 
            // textPasswordReg
            // 
            this.textPasswordReg.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textPasswordReg.Location = new System.Drawing.Point(286, 148);
            this.textPasswordReg.Name = "textPasswordReg";
            this.textPasswordReg.Size = new System.Drawing.Size(205, 27);
            this.textPasswordReg.TabIndex = 2;
            this.textPasswordReg.UseSystemPasswordChar = true;
            // 
            // textLoginReg
            // 
            this.textLoginReg.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textLoginReg.Location = new System.Drawing.Point(286, 106);
            this.textLoginReg.Name = "textLoginReg";
            this.textLoginReg.Size = new System.Drawing.Size(205, 27);
            this.textLoginReg.TabIndex = 1;
            // 
            // labelReg
            // 
            this.labelReg.AutoSize = true;
            this.labelReg.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelReg.Location = new System.Drawing.Point(320, 29);
            this.labelReg.Name = "labelReg";
            this.labelReg.Size = new System.Drawing.Size(131, 25);
            this.labelReg.TabIndex = 0;
            this.labelReg.Text = "Регистрация";
            // 
            // textPasswordRegRep
            // 
            this.textPasswordRegRep.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textPasswordRegRep.Location = new System.Drawing.Point(285, 193);
            this.textPasswordRegRep.Name = "textPasswordRegRep";
            this.textPasswordRegRep.Size = new System.Drawing.Size(205, 27);
            this.textPasswordRegRep.TabIndex = 5;
            this.textPasswordRegRep.UseSystemPasswordChar = true;
            // 
            // panelProfile
            // 
            this.panelProfile.Controls.Add(this.labelProfileName);
            this.panelProfile.Controls.Add(this.labelProfile);
            this.panelProfile.Enabled = false;
            this.panelProfile.Location = new System.Drawing.Point(118, 41);
            this.panelProfile.Name = "panelProfile";
            this.panelProfile.Size = new System.Drawing.Size(605, 368);
            this.panelProfile.TabIndex = 15;
            this.panelProfile.Visible = false;
            // 
            // labelProfile
            // 
            this.labelProfile.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelProfile.Location = new System.Drawing.Point(178, 11);
            this.labelProfile.Name = "labelProfile";
            this.labelProfile.Size = new System.Drawing.Size(248, 41);
            this.labelProfile.TabIndex = 0;
            this.labelProfile.Text = "Ваш профиль";
            // 
            // labelProfileName
            // 
            this.labelProfileName.AutoSize = true;
            this.labelProfileName.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelProfileName.Location = new System.Drawing.Point(251, 66);
            this.labelProfileName.Name = "labelProfileName";
            this.labelProfileName.Size = new System.Drawing.Size(75, 25);
            this.labelProfileName.TabIndex = 1;
            this.labelProfileName.Text = "label10";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panelAuthorization);
            this.Controls.Add(this.panelProfile);
            this.Controls.Add(this.panelRegistration);
            this.Controls.Add(this.panelWallets);
            this.Controls.Add(this.panelIncomes);
            this.Controls.Add(this.panelStat);
            this.Controls.Add(this.panelExpenses);
            this.Controls.Add(this.panelMain);
            this.Controls.Add(this.buttonMain);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.buttonProfile);
            this.Controls.Add(this.buttonWallets);
            this.Controls.Add(this.buttonStat);
            this.Controls.Add(this.buttonIncomes);
            this.Controls.Add(this.buttonExpenses);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form1";
            this.Text = "Учет финансов";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panelMain.ResumeLayout(false);
            this.Writes.ResumeLayout(false);
            this.Writes.PerformLayout();
            this.panelExpenses.ResumeLayout(false);
            this.Expense1.ResumeLayout(false);
            this.Expense1.PerformLayout();
            this.panelStat.ResumeLayout(false);
            this.panelIncomes.ResumeLayout(false);
            this.Income1.ResumeLayout(false);
            this.Income1.PerformLayout();
            this.panelWallets.ResumeLayout(false);
            this.Wallet1.ResumeLayout(false);
            this.Wallet1.PerformLayout();
            this.panelAuthorization.ResumeLayout(false);
            this.panelAuthorization.PerformLayout();
            this.panelRegistration.ResumeLayout(false);
            this.panelRegistration.PerformLayout();
            this.panelProfile.ResumeLayout(false);
            this.panelProfile.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonExpenses;
        private System.Windows.Forms.Button buttonIncomes;
        private System.Windows.Forms.Button buttonStat;
        private System.Windows.Forms.Button buttonWallets;
        private System.Windows.Forms.Button buttonProfile;
        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Button buttonMain;
        private System.Windows.Forms.Panel panelMain;
        private System.Windows.Forms.Label labelMain;
        private System.Windows.Forms.Button buttonCreateExspense;
        private System.Windows.Forms.Button buttonCreateIncome;
        private System.Windows.Forms.GroupBox Writes;
        private System.Windows.Forms.Label labelWallet;
        private System.Windows.Forms.Label labelType;
        private System.Windows.Forms.Label labelCategory;
        private System.Windows.Forms.Label labelAmount;
        private System.Windows.Forms.Label labelDate;
        private System.Windows.Forms.Panel panelExpenses;
        private System.Windows.Forms.GroupBox Expense1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button buttonAddExpense;
        private System.Windows.Forms.Label labelExpenses;
        private System.Windows.Forms.Panel panelStat;
        private System.Windows.Forms.Label labelStat;
        private System.Windows.Forms.Panel panelIncomes;
        private System.Windows.Forms.GroupBox Income1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button buttonAddIncome;
        private System.Windows.Forms.Label labelIncome;
        private System.Windows.Forms.Panel panelWallets;
        private System.Windows.Forms.GroupBox Wallet1;
        private System.Windows.Forms.Label labelWalletAmount;
        private System.Windows.Forms.Label labelWallets;
        private System.Windows.Forms.Panel panelAuthorization;
        private System.Windows.Forms.Label labelAuthorization;
        private System.Windows.Forms.TextBox textLogin;
        private System.Windows.Forms.Button buttonRegPanel;
        private System.Windows.Forms.Button buttonAuth;
        private System.Windows.Forms.Panel panelRegistration;
        private System.Windows.Forms.Button buttonAuthPanel;
        private System.Windows.Forms.Button buttonReg;
        private System.Windows.Forms.TextBox textLoginReg;
        private System.Windows.Forms.Label labelReg;
        private System.Windows.Forms.TextBox textPassword;
        private System.Windows.Forms.TextBox textPasswordRegRep;
        private System.Windows.Forms.TextBox textPasswordReg;
        private System.Windows.Forms.Panel panelProfile;
        private System.Windows.Forms.Label labelProfile;
        private System.Windows.Forms.Label labelProfileName;
    }
}

