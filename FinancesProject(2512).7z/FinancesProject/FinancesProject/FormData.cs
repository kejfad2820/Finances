﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinancesProject
{
    public partial class FormData : Form
    {
        public static int user_id;
        public int type_id;
        static string relativePath = @"..\..\UsersDB.mdf";
        string connectionString = $@"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog = UsersDB.mdf;AttachDbFilename={Path.Combine(AppDomain.CurrentDomain.BaseDirectory, relativePath)};Integrated Security=True";

        public FormData(int id)
        {
            InitializeComponent();
            user_id = id;
            radioButtonExpenseOfWrite.Checked = true;
            try
            {
                using(SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    string sql_wallets = "SELECT * FROM Wallets WHERE User_id = @user_id";  

                    SqlCommand select_wallets = new SqlCommand(sql_wallets, conn);

                    select_wallets.Parameters.AddWithValue("@user_id", user_id);

                    SqlDataReader reader = select_wallets.ExecuteReader();

                    comboBoxWalletsOfWrite.Items.Clear();

                    while (reader.Read())
                    {
                        string element = reader["Name"].ToString() + "(" + reader["Amount"].ToString() + " ₽)";
                        comboBoxWalletsOfWrite.Items.Add(element);
                        Debug.WriteLine(element);
                    }

                    reader.Close();

                    conn.Close();
                }
                Debug.WriteLine("Success connection");
            }
            catch(Exception ex)
            {
                Debug.WriteLine(ex.ToString());
            }
        }

        public void Show_Categories(int type_id)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                string sql_categories = "SELECT Name FROM Categories WHERE User_id = @user_id AND Type = @type_id";

                SqlCommand select_categories = new SqlCommand(sql_categories, conn);

                select_categories.Parameters.AddWithValue("@user_id", user_id);
                select_categories.Parameters.AddWithValue("@type_id", type_id);

                SqlDataReader reader_categories = select_categories.ExecuteReader();

                comboBoxCategoriesOfWrite.Items.Clear();

                while (reader_categories.Read())
                {
                    comboBoxCategoriesOfWrite.Items.Add(reader_categories["Name"].ToString());
                }

                reader_categories.Close();

                conn.Close();
            }
        }

        public void Calculate_Transactions(int wallet_id, double amount)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                string sql_money = "SELECT Amount + @amount FROM Wallets WHERE Id = @wallet_id";

                SqlCommand calc_money = new SqlCommand(sql_money, conn);

                calc_money.Parameters.AddWithValue("@amount", amount);
                calc_money.Parameters.AddWithValue("@wallet_id", wallet_id);

                double calc = (double)calc_money.ExecuteScalar();

                string sql_amount = "UPDATE Wallets SET Amount = @calc WHERE Id = @wallet_id";

                SqlCommand update_amount = new SqlCommand(sql_amount, conn);

                update_amount.Parameters.AddWithValue("@calc", calc);
                update_amount.Parameters.AddWithValue("@wallet_id", wallet_id);

                update_amount.ExecuteNonQuery();

                conn.Close();
            }
        }

        public void Create_Write(float amount, string description, string category, int type_id, DateTime date, string wallet, int user_id)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                int index = wallet.IndexOf("(");
                if(index != -1)
                {
                    wallet = wallet.Substring(0, index);
                }

                string sql_category = "SELECT Id FROM Categories WHERE Name = @category AND User_id = @user_id";

                SqlCommand select_category = new SqlCommand(sql_category, conn);

                select_category.Parameters.AddWithValue("@category", category);
                select_category.Parameters.AddWithValue("@user_id", user_id);

                int category_id = (int)select_category.ExecuteScalar();
                Debug.WriteLine(category_id);


                string sql_wallet = "SELECT Id FROM Wallets WHERE Name = @wallet AND User_id = @user_id";

                SqlCommand select_wallet = new SqlCommand(sql_wallet, conn);

                select_wallet.Parameters.AddWithValue("@wallet", wallet);
                select_wallet.Parameters.AddWithValue("@user_id", user_id);

                int wallet_id = (int)select_wallet.ExecuteScalar();

                //int value = Convert.ToInt32(amount);

                string sql_write = "INSERT INTO Transactions(Amount, Description, Category_id, Type_id, Date, Wallet_id, User_id) " +
                    "VALUES(@amount, @description, @category_id, @type_id, @date, @wallet_id, @user_id)";

                SqlCommand create_write = new SqlCommand(sql_write, conn);

                create_write.Parameters.AddWithValue("@amount", amount);
                create_write.Parameters.AddWithValue("@description", description);
                create_write.Parameters.AddWithValue("@category_id", category_id);
                create_write.Parameters.AddWithValue("@type_id", type_id);
                create_write.Parameters.AddWithValue("@date", date);
                create_write.Parameters.AddWithValue("@wallet_id", wallet_id);
                create_write.Parameters.AddWithValue("@user_id", user_id);

                create_write.ExecuteNonQuery();

                Debug.WriteLine("Success created of write");

                MessageBox.Show("Успешное создание записи", "Успешно", MessageBoxButtons.OK, MessageBoxIcon.Information);

                if(type_id == 0)
                {
                    amount = -amount;
                }

                Calculate_Transactions(wallet_id, amount);

                conn.Close();

                FormMain f2 = new FormMain(user_id);
                this.Hide();
                f2.ShowDialog();
                this.Close();
            }
        }

        private void buttonAddWrite_Click(object sender, EventArgs e)
        {

            if (comboBoxCategoriesOfWrite.Text == "" || textAmountOfWrite.Text == "" || comboBoxWalletsOfWrite.Text == "")
            {
                MessageBox.Show("Все поля должны быть заполнены", "Неверный ввод", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                Create_Write(Convert.ToSingle(textAmountOfWrite.Text), textDescriptionOfWrite.Text, comboBoxCategoriesOfWrite.Text, type_id, dateOfWrite.Value, comboBoxWalletsOfWrite.Text, user_id);
            }
        }

        private void buttonBackData_Click(object sender, EventArgs e)
        {
            FormMain f2 = new FormMain(user_id);
            this.Hide();
            f2.ShowDialog();
            this.Close();
        }

        private void FormData_Load(object sender, EventArgs e)
        {

        }

        private void radioButtonExpenseOfWrite_CheckedChanged(object sender, EventArgs e)
        {
            type_id = 0;
            Show_Categories(type_id);
        }

        private void radioButtonIncomeOfWrite_CheckedChanged(object sender, EventArgs e)
        {
            type_id = 1;
            Show_Categories(type_id);
        }
    }
}
