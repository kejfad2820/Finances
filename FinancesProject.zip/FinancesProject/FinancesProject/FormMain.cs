﻿using LiveCharts.Definitions.Charts;
using LiveCharts.Charts;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection.Emit;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using System.Windows.Markup;
using System.Runtime.CompilerServices;
using System.Xml.Linq;

namespace FinancesProject
{
    public partial class FormMain : Form
    {
        public int location_x_wallets = -105;
        public int location_y_wallets = 10;
        public int location_x_writes = -250;
        public int location_y_writes = 10;
        public Dictionary<GroupBox, int> groups_writes = new Dictionary<GroupBox, int>();
        public Dictionary<GroupBox, int> groups_wallets = new Dictionary<GroupBox, int>();
        public Dictionary<int, (int, string, string, int)> user_data = new Dictionary<int, (int, string, string, int)>();
        public static int user_id;
        public static string role_name;
        public int write_id = 0;
        static string relativePath = @"..\..\UsersDB.mdf";
        string connectionString = $@"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog = UsersDB.mdf;AttachDbFilename={Path.Combine(AppDomain.CurrentDomain.BaseDirectory, relativePath)};Integrated Security=True";

        public void OpenWindow(Panel panel)
        {
            panelWallets.Visible = false;
            panelWallets.Enabled = false;
            panelStat.Visible = false;
            panelStat.Enabled = false;
            panelMain.Visible = false;
            panelMain.Enabled = false;
            panelProfile.Enabled = false;
            panelProfile.Visible = false;
            panelAdmin.Enabled = false;
            panelAdmin.Visible = false;
            panel.Visible = true;
            panel.Enabled = true;
        }

        public FormMain(int id)
        {
            InitializeComponent();
            user_id = id;
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    Debug.WriteLine("Success connection");
                    OpenWindow(panelMain);
                    Debug.WriteLine("Main = " + user_id);
                }
                catch (SqlException ex)
                {
                    Debug.WriteLine(ex.Message);
                }
            }
            Show_Admin();
            Show_Writes();
        }

        public void Show_Admin()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                string sql_role = "SELECT ID_role FROM Users WHERE Id = @user_id";

                SqlCommand select_role = new SqlCommand(sql_role, conn);

                select_role.Parameters.AddWithValue("@user_id", user_id);

                int role_id = (int)select_role.ExecuteScalar();

                if(role_id == 2)
                {
                    buttonAdmin.Visible = true;
                }

                conn.Close();
            }
        }

        public void Create_Wallet(int id,string wallet_title, string balance, int i)
        {
            if(i == 0 || i == 4 || i == 8)
            {
                location_x_wallets = -105;
                if(i == 4 || i == 8)
                {
                    location_y_wallets += 105;
                }

            }
            location_x_wallets += 130;
            
            GroupBox groupBox = new GroupBox();
            panelWalletsElements.Controls.Add(groupBox);
            Button button = new Button();
            groupBox.Controls.Add(button);
            button.Location = new Point(50, 50);
            button.Size = new Size(60, 30);
            button.BackColor = Color.White;
            button.Text = "Удалить";
            button.Click += (s, e) => Delete_Wallet(groupBox);

            groupBox.Text = wallet_title;

            groupBox.Location = new Point(location_x_wallets, location_y_wallets);

            groupBox.Size = new Size(125, 100);

            System.Windows.Forms.Label labelBalance = new System.Windows.Forms.Label();
            groupBox.Controls.Add(labelBalance);
            labelBalance.Location = new Point(5, 25);
            labelBalance.Text = balance + " ₽";
            groupBox.Visible = true;
            groups_wallets.Add(groupBox, id);
        }


        public void Delete_Wallet(GroupBox groupbox)
        {
            using(SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                panelWalletsElements.Controls.Remove(groupbox);

                string sql_trans = "DELETE FROM Transactions WHERE Wallet_id = @id";

                SqlCommand select_trans = new SqlCommand(sql_trans, conn);

                select_trans.Parameters.AddWithValue("@id", groups_wallets[groupbox]);

                select_trans.ExecuteNonQuery();

                string sql_wallet = "DELETE FROM Wallets WHERE Id = @id";

                SqlCommand delete_wallet = new SqlCommand(sql_wallet, conn);

                delete_wallet.Parameters.AddWithValue("@id", groups_wallets[groupbox]);

                delete_wallet.ExecuteNonQuery();

                conn.Close();

                MessageBox.Show("Успешное удаление кошелька", "Успешно", MessageBoxButtons.OK, MessageBoxIcon.Information);

                Show_Wallets();
            }
        }

        public void Show_Wallets()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                panelWalletsElements.Controls.Clear();

                string sql_wallet = "SELECT Id, Name, Amount FROM Wallets WHERE User_id = @user_id";

                SqlCommand select_wallet = new SqlCommand(sql_wallet, conn);

                select_wallet.Parameters.AddWithValue("@user_id", user_id);

                SqlDataReader reader = select_wallet.ExecuteReader();

                int i = 0;

                while (reader.Read())
                {
                    string wallet_name = reader["Name"].ToString();
                    float wallet_amount = Convert.ToSingle(reader["Amount"]);
                    Create_Wallet((int)reader["Id"], reader["Name"].ToString(), wallet_amount.ToString(), i);
                    i++;
                }

                reader.Close();

                conn.Close();
            }
        }

        public void Create_Writes(int id, string amount, string category_id, string type_id, string date, string wallet_id, int i)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                string category_name;
                string sql_category = "SELECT Name FROM Categories WHERE Id = @category_id";

                SqlCommand select_category = new SqlCommand(sql_category, conn);

                select_category.Parameters.AddWithValue("@category_id", category_id);

                SqlDataReader reader_category = select_category.ExecuteReader();

                reader_category.Read();

                category_name = reader_category["Name"].ToString();

                reader_category.Close();

                string wallet_name;
                string sql_wallet = "SELECT Name FROM Wallets WHERE Id = @wallet_id";

                SqlCommand select_wallet = new SqlCommand( sql_wallet, conn);

                select_wallet.Parameters.AddWithValue("@wallet_id", wallet_id);

                SqlDataReader reader_wallet = select_wallet.ExecuteReader();

                reader_wallet.Read();

                wallet_name = reader_wallet["Name"].ToString();
                reader_wallet.Close();

                string type_name;

                if(type_id == "0")
                {
                    type_name = "Расход";
                }
                else
                {
                    type_name = "Доход";
                }

                if (i == 0)
                {
                    location_x_writes = -250;
                    location_y_writes = 10;
                }
                else if (i == 2 || i == 4 || i == 6 || i == 8 || i == 10)
                {
                    location_x_writes = -250;
                    location_y_writes += 110;

                }
                location_x_writes += 270;

                GroupBox groupBox = new GroupBox();
                panelWrites.Controls.Add(groupBox);

                groupBox.Location = new Point(location_x_writes, location_y_writes);

                groupBox.Size = new Size(260, 100);

                System.Windows.Forms.Label labelAmount = new System.Windows.Forms.Label();
                System.Windows.Forms.Label labelCategory = new System.Windows.Forms.Label();
                System.Windows.Forms.Label labelType = new System.Windows.Forms.Label();
                System.Windows.Forms.Label labelWallet = new System.Windows.Forms.Label();
                System.Windows.Forms.Label labelDate = new System.Windows.Forms.Label();
                System.Windows.Forms.Button button = new System.Windows.Forms.Button();

                groupBox.Controls.Add(button);
                button.Location = new Point(155, 20);
                button.Size = new Size(60, 30);
                button.BackColor = Color.White;
                button.Text = "Удалить";
                button.Click += (s, e) => Delete_Write(groupBox);

                groupBox.Controls.Add(labelAmount);
                labelAmount.Location = new Point(20, 20);
                labelAmount.Text = amount + " ₽";

                groupBox.Text = category_name;

                groupBox.Controls.Add(labelType);
                labelType.Location = new Point(20, 70);
                labelType.Text = "Тип: " + type_name;

                groupBox.Controls.Add(labelWallet);
                labelWallet.Location = new Point(20, 45);
                labelWallet.Text = "Кошелек: " + wallet_name;

                groupBox.Controls.Add(labelDate);
                labelDate.Location = new Point(155, 70);
                labelDate.Text = "Дата: " + date;

                groupBox.BackColor = System.Drawing.Color.LightSlateGray;
                groupBox.FlatStyle = FlatStyle.Flat;
                groupBox.Visible = true;

                groups_writes.Add(groupBox, id);

                conn.Close();
            }
        }

        public void Delete_Write(GroupBox groupbox)
        {
            using(SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                panelWrites.Controls.Remove(groupbox);

                string sql_trans = "DELETE FROM Transactions WHERE Id = @id";

                SqlCommand select_trans = new SqlCommand(sql_trans, conn);

                select_trans.Parameters.AddWithValue("@id", groups_writes[groupbox]);

                select_trans.ExecuteNonQuery();

                MessageBox.Show("Успешное удаление транзакции", "Успешно", MessageBoxButtons.OK, MessageBoxIcon.Information);

                conn.Close();
            }

        }

        public void Show_Writes()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                string sql_wallet = "SELECT Id, Amount, Category_id, Type_id, Date, Wallet_id FROM Transactions WHERE User_id = @user_id";

                SqlCommand select_wallet = new SqlCommand(sql_wallet, conn);

                select_wallet.Parameters.AddWithValue("@user_id", user_id);

                SqlDataReader reader = select_wallet.ExecuteReader();

                int i = 0;

                while (reader.Read())
                {
                    Create_Writes((int)reader["Id"], reader["Amount"].ToString(), reader["Category_id"].ToString(), reader["Type_id"].ToString(), reader["Date"].ToString(), reader["Wallet_id"].ToString(), i);
                    i++;
                }

                reader.Close();

                conn.Close();
            }
        }

        public void Show_Profile()
        {
            using(SqlConnection conn = new SqlConnection(connectionString))
            {
                string profile_name;
                conn.Open();

                string sql_profile = "SELECT Login FROM Users WHERE Id = @user_id";

                SqlCommand select_profile = new SqlCommand(sql_profile, conn);

                select_profile.Parameters.AddWithValue("@user_id", user_id);

                SqlDataReader reader_profile = select_profile.ExecuteReader();

                reader_profile.Read();

                profile_name = reader_profile["Login"].ToString();

                reader_profile.Close();

                labelProfileName.Text = profile_name.ToString();

                conn.Close();
            }
        }

        private void buttonProfile_Click(object sender, EventArgs e)
        {
            OpenWindow(panelProfile);

            Show_Profile();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void buttonMain_Click(object sender, EventArgs e)
        {
            OpenWindow(panelMain);
            panelWrites.Controls.Clear();
            Show_Writes();
            location_x_writes = -250;
            location_y_writes = 10;
        }

        public void Show_Stat()
        {
            using(SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                List<int> categories_id = new List<int>();
                List<float> transactions = new List<float>();
                List<string> categories = new List<string>();
                float amount = 0;
                chart1.Series.Clear();
                chart1.Series.Add("value");
                chart1.Series[0].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Pie;

                string sql_categories_id = "SELECT Id FROM Categories WHERE User_id = @user_id AND Type = 0";

                SqlCommand select_categories_id = new SqlCommand(sql_categories_id, conn);

                select_categories_id.Parameters.AddWithValue("@user_id", user_id);

                SqlDataReader reader_categories_id = select_categories_id.ExecuteReader();

                categories_id.Clear();

                while (reader_categories_id.Read())
                {
                    categories_id.Add((int)reader_categories_id["Id"]);
                }
                reader_categories_id.Close();

                string sql_transactions = "SELECT Amount FROM Transactions WHERE Category_id = @category_id";

                SqlCommand select_transactions = new SqlCommand(sql_transactions, conn);

                transactions.Clear();

                for (int i = 0; i < categories_id.Count; i++)
                {
                    if(categories_id[i] != null)
                    {
                        select_transactions.Parameters.AddWithValue("@category_id", categories_id[i]);

                        SqlDataReader reader_transactions = select_transactions.ExecuteReader();

                        amount = 0;

                        while (reader_transactions.Read())
                        {
                            if (reader_transactions["Amount"] != DBNull.Value || reader_transactions["Amount"] != null)
                            {
                                amount += Convert.ToSingle(reader_transactions["Amount"]);
                                Debug.WriteLine(reader_transactions["Amount"]);
                            }
                            else
                            {
                                reader_transactions.Close();
                            }
                        }
                        transactions.Add(amount);
                        reader_transactions.Close();
                        select_transactions.Parameters.Clear();
                    }
                    else
                    {
                        break;
                    }

                    string sql_categories = "SELECT Name FROM Categories WHERE Id = @category_id";

                    SqlCommand select_category = new SqlCommand(sql_categories, conn);

                    select_category.Parameters.AddWithValue("@category_id", categories_id[i]);

                    SqlDataReader reader_categories = select_category.ExecuteReader();

                    while (reader_categories.Read())
                    {
                        categories.Add(reader_categories["Name"].ToString());
                    }

                    reader_categories.Close();

                    chart1.Series[0].Points.Add(transactions[i]);
                    chart1.Series[0].Points[i].LegendText = categories[i].ToString();
                    chart1.Series[0].Points[i].Label = transactions[i].ToString() + " ₽";

                    select_category.Parameters.Clear();

                }
                conn.Close();
            }
        }

        private void buttonStat_Click(object sender, EventArgs e)
        {
            OpenWindow(panelStat);

            Show_Stat();
        }

        private void buttonWallets_Click(object sender, EventArgs e)
        {
            OpenWindow(panelWallets);
            panelWalletsElements.Controls.Clear();
            Show_Wallets();
            location_x_wallets = -105;
            location_y_wallets = 10;
        }

        private void panelMain_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panelExpenses_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Expense1_Enter(object sender, EventArgs e)
        {

        }

        private void buttonAddExpense_Click(object sender, EventArgs e)
        {

        }

        private void panelIncomes_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Income1_Enter(object sender, EventArgs e)
        {

        }

        private void buttonAddIncome_Click(object sender, EventArgs e)
        {

        }

        private void panelWallets_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Wallet1_Enter(object sender, EventArgs e)
        {

        }

        private void panelStat_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void buttonAddTransaction_Click(object sender, EventArgs e)
        {
            FormData f3 = new FormData(user_id);
            this.Hide();
            f3.ShowDialog();
            this.Close();
        }

        private void buttonAddCategory_Click(object sender, EventArgs e)
        {
            FormCategory f4 = new FormCategory(user_id);
            this.Hide();
            f4.ShowDialog();
            this.Close();
        }

        private void buttonAddWallet_Click(object sender, EventArgs e)
        {
            FormWallet f5 = new FormWallet(user_id);
            this.Hide();
            f5.ShowDialog();
            this.Close();
        }

        private void buttonAdmin_Click(object sender, EventArgs e)
        {
            OpenWindow(panelAdmin);

            user_data.Clear();
            dataGridViewUsers.Columns.Clear();

            Show_Data();
        }

        public void Show_Data()
        {
            using(SqlConnection conn = new SqlConnection(connectionString))
            {
                user_data.Clear();
                conn.Open();

                string sql_data = "SELECT Id, Login, Email, Id_role FROM Users WHERE Id != @user_id";

                SqlCommand show_data = new SqlCommand(sql_data, conn);

                show_data.Parameters.AddWithValue("@user_id", user_id);

                SqlDataReader reader = show_data.ExecuteReader();

                int i = 0;

                while (reader.Read())
                {
                    user_data.Add(i, ((int)reader["Id"], reader["Login"].ToString(), reader["Email"].ToString(), (int)reader["Id_role"]));
                    i++;
                }

                reader.Close();

                dataGridViewUsers.Columns.Add("Id", "Id");
                dataGridViewUsers.Columns.Add("Login", "Логин");
                dataGridViewUsers.Columns.Add("Email", "Почта");
                dataGridViewUsers.Columns.Add("Role_id", "Id_роли");

                for (int j = 0; j < user_data.Count; j++)
                {
                    DataGridViewButtonColumn button = new DataGridViewButtonColumn();
                    button.Text = "Удалить";
                    button.HeaderText = "Удаление";
                    button.UseColumnTextForButtonValue = true;
                    dataGridViewUsers.Columns.Add(button);

                    dataGridViewUsers.Rows.Add(user_data[j].Item1, user_data[j].Item2, user_data[j].Item3, user_data[j].Item4);
                    dataGridViewUsers.CellContentClick += DataGridViewUsers_CellContentClick;
                }

                conn.Close();


            }
        }

        private void DataGridViewUsers_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            Delete_user(user_data[e.RowIndex].Item1);
        }

        public void Edit_db_data(int id, string login, string email, int role_id)
        {
            using(SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                if (!string.IsNullOrWhiteSpace(login))
                {
                    string sql_user = "UPDATE Users SET Login = @login, Email = @email," +
                    "ID_role = @role_id WHERE Id = @id";

                    SqlCommand update_data = new SqlCommand(sql_user, conn);

                    update_data.Parameters.AddWithValue("@id", id);
                    update_data.Parameters.AddWithValue("@login", login);
                    update_data.Parameters.AddWithValue("@email", email);
                    update_data.Parameters.AddWithValue("@role_id", role_id);

                    update_data.ExecuteNonQuery();

                    conn.Close();
                }
                else
                {
                    MessageBox.Show("Нет ни одного пользователя", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                
            }
        }

        public void Delete_user(int id)
        {
            using(SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                string sql_trans = "DELETE FROM Transactions WHERE User_id = @id";

                SqlCommand select_trans = new SqlCommand(sql_trans, conn);

                select_trans.Parameters.AddWithValue("@id", id);

                select_trans.ExecuteNonQuery();


                string sql_wallet = "DELETE FROM Wallets WHERE User_id = @id";

                SqlCommand delete_wallet = new SqlCommand(sql_wallet, conn);

                delete_wallet.Parameters.AddWithValue("@id", id);

                delete_wallet.ExecuteNonQuery();

                string sql_categories = "DELETE FROM Categories WHERE User_id = @id";

                SqlCommand delete_categories = new SqlCommand(sql_categories, conn);

                delete_categories.Parameters.AddWithValue("@id", id);

                delete_categories.ExecuteNonQuery();


                string sql_user = "DELETE FROM Users WHERE Id = @id";

                SqlCommand delete_user = new SqlCommand(sql_user, conn);

                delete_user.Parameters.AddWithValue("@id", id);

                delete_user.ExecuteNonQuery();

                MessageBox.Show("Успешное удаление пользователя", "Успешно", MessageBoxButtons.OK, MessageBoxIcon.Information);

                Show_Data();
                conn.Close();
            }
        }

        public void Edit_data()
        {
            using(SqlConnection conn = new SqlConnection(connectionString))
            {
                if (dataGridViewUsers.Rows.Count == 0)
                {
                    MessageBox.Show("Нет ни одного пользователя", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    conn.Open();

                    int j = 0;

                    for (int i = 0; i < user_data.Count; i++)
                    {
                        if (dataGridViewUsers.Rows[i].Cells[0].Value.ToString() == user_data[i].Item1.ToString())
                        {
                            j++;
                        }
                        else
                        {
                            MessageBox.Show("Нельзя поменять Id пользователя", "Неверный ввод", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            dataGridViewUsers.Rows[i].Cells[0].Value = user_data[i].Item1;
                        }
                        if (dataGridViewUsers.Rows[i].Cells[1].Value == user_data[i].Item2.ToString())
                        {
                            j++;
                        }
                        else
                        {
                            int id = (int)dataGridViewUsers.Rows[i].Cells[0].Value;
                            string login = dataGridViewUsers.Rows[i].Cells[1].Value.ToString();
                            string email = dataGridViewUsers.Rows[i].Cells[2].Value.ToString();
                            int role_id = (int)dataGridViewUsers.Rows[i].Cells[3].Value;
                            Edit_db_data(id, login, email, role_id);
                        }
                        if (dataGridViewUsers.Rows[i].Cells[2].Value == user_data[i].Item3.ToString())
                        {
                            j++;
                        }
                        else
                        {
                            int id = (int)dataGridViewUsers.Rows[i].Cells[0].Value;
                            string login = dataGridViewUsers.Rows[i].Cells[1].Value.ToString();
                            string email = dataGridViewUsers.Rows[i].Cells[2].Value.ToString();
                            int role_id = (int)dataGridViewUsers.Rows[i].Cells[3].Value;
                            Edit_db_data(id, login, email, role_id);
                        }
                        if (dataGridViewUsers.Rows[i].Cells[3].Value.ToString() == user_data[i].Item4.ToString())
                        {
                            j++;
                        }
                        else
                        {
                            int id = (int)dataGridViewUsers.Rows[i].Cells[0].Value;
                            string login = dataGridViewUsers.Rows[i].Cells[1].Value.ToString();
                            string email = dataGridViewUsers.Rows[i].Cells[2].Value.ToString();
                            int role_id = Convert.ToInt32(dataGridViewUsers.Rows[i].Cells[3].Value);
                            Edit_db_data(id, login, email, role_id);
                        }
                    }

                    Debug.WriteLine(dataGridViewUsers.Rows[0].Cells[0].Value);
                    Debug.WriteLine(user_data[0].Item1.ToString());

                    conn.Close();
                }
                
            }
        }

        private void buttonEdit_Click(object sender, EventArgs e)
        {
            Edit_data();
        }
    }
}
