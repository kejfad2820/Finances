﻿namespace FinancesProject
{
    partial class FormCategory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonBackCategory = new System.Windows.Forms.Button();
            this.buttonAddCategory = new System.Windows.Forms.Button();
            this.labelTypeOfCategory = new System.Windows.Forms.Label();
            this.labelNameOfCategory = new System.Windows.Forms.Label();
            this.textNameOfCategory = new System.Windows.Forms.TextBox();
            this.comboBoxTypeOfCategory = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // buttonBackCategory
            // 
            this.buttonBackCategory.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonBackCategory.Location = new System.Drawing.Point(458, 365);
            this.buttonBackCategory.Margin = new System.Windows.Forms.Padding(4);
            this.buttonBackCategory.Name = "buttonBackCategory";
            this.buttonBackCategory.Size = new System.Drawing.Size(173, 47);
            this.buttonBackCategory.TabIndex = 38;
            this.buttonBackCategory.Text = "Назад";
            this.buttonBackCategory.UseVisualStyleBackColor = true;
            this.buttonBackCategory.Click += new System.EventHandler(this.buttonBackCategory_Click);
            // 
            // buttonAddCategory
            // 
            this.buttonAddCategory.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonAddCategory.Location = new System.Drawing.Point(458, 293);
            this.buttonAddCategory.Margin = new System.Windows.Forms.Padding(4);
            this.buttonAddCategory.Name = "buttonAddCategory";
            this.buttonAddCategory.Size = new System.Drawing.Size(173, 47);
            this.buttonAddCategory.TabIndex = 37;
            this.buttonAddCategory.Text = "Добавить";
            this.buttonAddCategory.UseVisualStyleBackColor = true;
            this.buttonAddCategory.Click += new System.EventHandler(this.buttonAddCategory_Click);
            // 
            // labelTypeOfCategory
            // 
            this.labelTypeOfCategory.AutoSize = true;
            this.labelTypeOfCategory.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.labelTypeOfCategory.Location = new System.Drawing.Point(352, 220);
            this.labelTypeOfCategory.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelTypeOfCategory.Name = "labelTypeOfCategory";
            this.labelTypeOfCategory.Size = new System.Drawing.Size(48, 26);
            this.labelTypeOfCategory.TabIndex = 36;
            this.labelTypeOfCategory.Text = "Тип";
            // 
            // labelNameOfCategory
            // 
            this.labelNameOfCategory.AutoSize = true;
            this.labelNameOfCategory.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.labelNameOfCategory.Location = new System.Drawing.Point(289, 164);
            this.labelNameOfCategory.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelNameOfCategory.Name = "labelNameOfCategory";
            this.labelNameOfCategory.Size = new System.Drawing.Size(111, 26);
            this.labelNameOfCategory.TabIndex = 35;
            this.labelNameOfCategory.Text = "Название";
            this.labelNameOfCategory.Click += new System.EventHandler(this.labelNameOfCategory_Click);
            // 
            // textNameOfCategory
            // 
            this.textNameOfCategory.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textNameOfCategory.Location = new System.Drawing.Point(408, 161);
            this.textNameOfCategory.Margin = new System.Windows.Forms.Padding(4);
            this.textNameOfCategory.Name = "textNameOfCategory";
            this.textNameOfCategory.Size = new System.Drawing.Size(272, 32);
            this.textNameOfCategory.TabIndex = 33;
            // 
            // comboBoxTypeOfCategory
            // 
            this.comboBoxTypeOfCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxTypeOfCategory.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBoxTypeOfCategory.FormattingEnabled = true;
            this.comboBoxTypeOfCategory.Items.AddRange(new object[] {
            "Доход",
            "Расход"});
            this.comboBoxTypeOfCategory.Location = new System.Drawing.Point(408, 217);
            this.comboBoxTypeOfCategory.Margin = new System.Windows.Forms.Padding(4);
            this.comboBoxTypeOfCategory.Name = "comboBoxTypeOfCategory";
            this.comboBoxTypeOfCategory.Size = new System.Drawing.Size(272, 34);
            this.comboBoxTypeOfCategory.TabIndex = 39;
            this.comboBoxTypeOfCategory.SelectedIndexChanged += new System.EventHandler(this.comboBoxTypeOfCategory_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(416, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(254, 29);
            this.label1.TabIndex = 40;
            this.label1.Text = "Добавить категорию";
            // 
            // FormCategory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboBoxTypeOfCategory);
            this.Controls.Add(this.buttonBackCategory);
            this.Controls.Add(this.buttonAddCategory);
            this.Controls.Add(this.labelTypeOfCategory);
            this.Controls.Add(this.labelNameOfCategory);
            this.Controls.Add(this.textNameOfCategory);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FormCategory";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Учет финансов";
            this.Load += new System.EventHandler(this.FormCategory_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonBackCategory;
        private System.Windows.Forms.Button buttonAddCategory;
        private System.Windows.Forms.Label labelTypeOfCategory;
        private System.Windows.Forms.Label labelNameOfCategory;
        private System.Windows.Forms.TextBox textNameOfCategory;
        private System.Windows.Forms.ComboBox comboBoxTypeOfCategory;
        private System.Windows.Forms.Label label1;
    }
}