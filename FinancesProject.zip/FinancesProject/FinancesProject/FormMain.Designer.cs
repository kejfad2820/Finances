﻿namespace FinancesProject
{
    partial class FormMain
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea5 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend5 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series5 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.buttonStat = new System.Windows.Forms.Button();
            this.buttonWallets = new System.Windows.Forms.Button();
            this.buttonProfile = new System.Windows.Forms.Button();
            this.buttonExit = new System.Windows.Forms.Button();
            this.buttonMain = new System.Windows.Forms.Button();
            this.panelMain = new System.Windows.Forms.Panel();
            this.panelWrites = new System.Windows.Forms.Panel();
            this.Writes = new System.Windows.Forms.GroupBox();
            this.labelDate = new System.Windows.Forms.Label();
            this.labelWallet = new System.Windows.Forms.Label();
            this.labelType = new System.Windows.Forms.Label();
            this.labelCategory = new System.Windows.Forms.Label();
            this.labelAmount = new System.Windows.Forms.Label();
            this.buttonAddTransaction = new System.Windows.Forms.Button();
            this.buttonAddCategory = new System.Windows.Forms.Button();
            this.buttonAddWallet = new System.Windows.Forms.Button();
            this.labelMain = new System.Windows.Forms.Label();
            this.panelStat = new System.Windows.Forms.Panel();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.labelStat = new System.Windows.Forms.Label();
            this.panelWallets = new System.Windows.Forms.Panel();
            this.panelWalletsElements = new System.Windows.Forms.Panel();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Wallet1 = new System.Windows.Forms.GroupBox();
            this.labelWalletAmount = new System.Windows.Forms.Label();
            this.labelWallets = new System.Windows.Forms.Label();
            this.panelProfile = new System.Windows.Forms.Panel();
            this.labelProfileName = new System.Windows.Forms.Label();
            this.labelProfile = new System.Windows.Forms.Label();
            this.buttonAdmin = new System.Windows.Forms.Button();
            this.panelAdmin = new System.Windows.Forms.Panel();
            this.buttonEdit = new System.Windows.Forms.Button();
            this.dataGridViewUsers = new System.Windows.Forms.DataGridView();
            this.labelAdmin = new System.Windows.Forms.Label();
            this.panelMain.SuspendLayout();
            this.panelWrites.SuspendLayout();
            this.Writes.SuspendLayout();
            this.panelStat.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            this.panelWallets.SuspendLayout();
            this.panelWalletsElements.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.Wallet1.SuspendLayout();
            this.panelProfile.SuspendLayout();
            this.panelAdmin.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewUsers)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonStat
            // 
            this.buttonStat.Location = new System.Drawing.Point(20, 246);
            this.buttonStat.Margin = new System.Windows.Forms.Padding(4);
            this.buttonStat.Name = "buttonStat";
            this.buttonStat.Size = new System.Drawing.Size(133, 68);
            this.buttonStat.TabIndex = 2;
            this.buttonStat.Text = "Статистика";
            this.buttonStat.UseVisualStyleBackColor = true;
            this.buttonStat.Click += new System.EventHandler(this.buttonStat_Click);
            // 
            // buttonWallets
            // 
            this.buttonWallets.Location = new System.Drawing.Point(20, 320);
            this.buttonWallets.Margin = new System.Windows.Forms.Padding(4);
            this.buttonWallets.Name = "buttonWallets";
            this.buttonWallets.Size = new System.Drawing.Size(133, 68);
            this.buttonWallets.TabIndex = 3;
            this.buttonWallets.Text = "Кошельки";
            this.buttonWallets.UseVisualStyleBackColor = true;
            this.buttonWallets.Click += new System.EventHandler(this.buttonWallets_Click);
            // 
            // buttonProfile
            // 
            this.buttonProfile.Location = new System.Drawing.Point(878, 13);
            this.buttonProfile.Margin = new System.Windows.Forms.Padding(4);
            this.buttonProfile.Name = "buttonProfile";
            this.buttonProfile.Size = new System.Drawing.Size(173, 47);
            this.buttonProfile.TabIndex = 4;
            this.buttonProfile.Text = "Профиль";
            this.buttonProfile.UseVisualStyleBackColor = true;
            this.buttonProfile.Click += new System.EventHandler(this.buttonProfile_Click);
            // 
            // buttonExit
            // 
            this.buttonExit.Location = new System.Drawing.Point(878, 492);
            this.buttonExit.Margin = new System.Windows.Forms.Padding(4);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(173, 47);
            this.buttonExit.TabIndex = 5;
            this.buttonExit.Text = "Выйти";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // buttonMain
            // 
            this.buttonMain.Location = new System.Drawing.Point(20, 172);
            this.buttonMain.Margin = new System.Windows.Forms.Padding(4);
            this.buttonMain.Name = "buttonMain";
            this.buttonMain.Size = new System.Drawing.Size(133, 68);
            this.buttonMain.TabIndex = 6;
            this.buttonMain.Text = "Главная";
            this.buttonMain.UseVisualStyleBackColor = true;
            this.buttonMain.Click += new System.EventHandler(this.buttonMain_Click);
            // 
            // panelMain
            // 
            this.panelMain.Controls.Add(this.panelWrites);
            this.panelMain.Controls.Add(this.buttonAddTransaction);
            this.panelMain.Controls.Add(this.buttonAddCategory);
            this.panelMain.Controls.Add(this.buttonAddWallet);
            this.panelMain.Controls.Add(this.labelMain);
            this.panelMain.Enabled = false;
            this.panelMain.Location = new System.Drawing.Point(157, 50);
            this.panelMain.Margin = new System.Windows.Forms.Padding(4);
            this.panelMain.Name = "panelMain";
            this.panelMain.Size = new System.Drawing.Size(800, 453);
            this.panelMain.TabIndex = 7;
            this.panelMain.Visible = false;
            this.panelMain.Paint += new System.Windows.Forms.PaintEventHandler(this.panelMain_Paint);
            // 
            // panelWrites
            // 
            this.panelWrites.AutoScroll = true;
            this.panelWrites.Controls.Add(this.Writes);
            this.panelWrites.Location = new System.Drawing.Point(20, 62);
            this.panelWrites.Margin = new System.Windows.Forms.Padding(4);
            this.panelWrites.Name = "panelWrites";
            this.panelWrites.Size = new System.Drawing.Size(760, 318);
            this.panelWrites.TabIndex = 6;
            // 
            // Writes
            // 
            this.Writes.BackColor = System.Drawing.Color.LightSlateGray;
            this.Writes.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Writes.Controls.Add(this.labelDate);
            this.Writes.Controls.Add(this.labelWallet);
            this.Writes.Controls.Add(this.labelType);
            this.Writes.Controls.Add(this.labelCategory);
            this.Writes.Controls.Add(this.labelAmount);
            this.Writes.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.Writes.Location = new System.Drawing.Point(27, 12);
            this.Writes.Margin = new System.Windows.Forms.Padding(4);
            this.Writes.Name = "Writes";
            this.Writes.Padding = new System.Windows.Forms.Padding(4);
            this.Writes.Size = new System.Drawing.Size(347, 123);
            this.Writes.TabIndex = 3;
            this.Writes.TabStop = false;
            this.Writes.Text = "Запись 1";
            this.Writes.Visible = false;
            // 
            // labelDate
            // 
            this.labelDate.AutoSize = true;
            this.labelDate.Location = new System.Drawing.Point(213, 86);
            this.labelDate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelDate.Name = "labelDate";
            this.labelDate.Size = new System.Drawing.Size(39, 16);
            this.labelDate.TabIndex = 4;
            this.labelDate.Text = "Дата";
            // 
            // labelWallet
            // 
            this.labelWallet.AutoSize = true;
            this.labelWallet.Location = new System.Drawing.Point(213, 55);
            this.labelWallet.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelWallet.Name = "labelWallet";
            this.labelWallet.Size = new System.Drawing.Size(63, 16);
            this.labelWallet.TabIndex = 3;
            this.labelWallet.Text = "Кошелек";
            // 
            // labelType
            // 
            this.labelType.AutoSize = true;
            this.labelType.Location = new System.Drawing.Point(27, 86);
            this.labelType.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelType.Name = "labelType";
            this.labelType.Size = new System.Drawing.Size(32, 16);
            this.labelType.TabIndex = 2;
            this.labelType.Text = "Тип";
            // 
            // labelCategory
            // 
            this.labelCategory.AutoSize = true;
            this.labelCategory.Location = new System.Drawing.Point(27, 55);
            this.labelCategory.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelCategory.Name = "labelCategory";
            this.labelCategory.Size = new System.Drawing.Size(75, 16);
            this.labelCategory.TabIndex = 1;
            this.labelCategory.Text = "Категория";
            // 
            // labelAmount
            // 
            this.labelAmount.AutoSize = true;
            this.labelAmount.Location = new System.Drawing.Point(27, 25);
            this.labelAmount.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelAmount.Name = "labelAmount";
            this.labelAmount.Size = new System.Drawing.Size(50, 16);
            this.labelAmount.TabIndex = 0;
            this.labelAmount.Text = "Сумма";
            // 
            // buttonAddTransaction
            // 
            this.buttonAddTransaction.Location = new System.Drawing.Point(124, 396);
            this.buttonAddTransaction.Margin = new System.Windows.Forms.Padding(4);
            this.buttonAddTransaction.Name = "buttonAddTransaction";
            this.buttonAddTransaction.Size = new System.Drawing.Size(173, 47);
            this.buttonAddTransaction.TabIndex = 1;
            this.buttonAddTransaction.Text = "Добавить транзакцию";
            this.buttonAddTransaction.UseVisualStyleBackColor = true;
            this.buttonAddTransaction.Click += new System.EventHandler(this.buttonAddTransaction_Click);
            // 
            // buttonAddCategory
            // 
            this.buttonAddCategory.Location = new System.Drawing.Point(320, 396);
            this.buttonAddCategory.Margin = new System.Windows.Forms.Padding(4);
            this.buttonAddCategory.Name = "buttonAddCategory";
            this.buttonAddCategory.Size = new System.Drawing.Size(173, 47);
            this.buttonAddCategory.TabIndex = 4;
            this.buttonAddCategory.Text = "Добавить категорию";
            this.buttonAddCategory.UseVisualStyleBackColor = true;
            this.buttonAddCategory.Click += new System.EventHandler(this.buttonAddCategory_Click);
            // 
            // buttonAddWallet
            // 
            this.buttonAddWallet.Location = new System.Drawing.Point(511, 396);
            this.buttonAddWallet.Margin = new System.Windows.Forms.Padding(4);
            this.buttonAddWallet.Name = "buttonAddWallet";
            this.buttonAddWallet.Size = new System.Drawing.Size(173, 47);
            this.buttonAddWallet.TabIndex = 5;
            this.buttonAddWallet.Text = "Добавить кошелек";
            this.buttonAddWallet.UseVisualStyleBackColor = true;
            this.buttonAddWallet.Click += new System.EventHandler(this.buttonAddWallet_Click);
            // 
            // labelMain
            // 
            this.labelMain.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelMain.Location = new System.Drawing.Point(332, 14);
            this.labelMain.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelMain.Name = "labelMain";
            this.labelMain.Size = new System.Drawing.Size(204, 50);
            this.labelMain.TabIndex = 0;
            this.labelMain.Text = "Главная";
            // 
            // panelStat
            // 
            this.panelStat.Controls.Add(this.chart1);
            this.panelStat.Controls.Add(this.labelStat);
            this.panelStat.Enabled = false;
            this.panelStat.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.panelStat.Location = new System.Drawing.Point(157, 50);
            this.panelStat.Margin = new System.Windows.Forms.Padding(4);
            this.panelStat.Name = "panelStat";
            this.panelStat.Size = new System.Drawing.Size(807, 453);
            this.panelStat.TabIndex = 10;
            this.panelStat.Visible = false;
            this.panelStat.Paint += new System.Windows.Forms.PaintEventHandler(this.panelStat_Paint);
            // 
            // chart1
            // 
            chartArea5.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea5);
            this.chart1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            legend5.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            legend5.IsTextAutoFit = false;
            legend5.Name = "Legend1";
            legend5.TableStyle = System.Windows.Forms.DataVisualization.Charting.LegendTableStyle.Tall;
            this.chart1.Legends.Add(legend5);
            this.chart1.Location = new System.Drawing.Point(103, 68);
            this.chart1.Margin = new System.Windows.Forms.Padding(4);
            this.chart1.Name = "chart1";
            series5.ChartArea = "ChartArea1";
            series5.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Pie;
            series5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            series5.Legend = "Legend1";
            series5.Name = "Series1";
            this.chart1.Series.Add(series5);
            this.chart1.Size = new System.Drawing.Size(612, 369);
            this.chart1.TabIndex = 1;
            // 
            // labelStat
            // 
            this.labelStat.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelStat.Location = new System.Drawing.Point(298, 14);
            this.labelStat.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelStat.Name = "labelStat";
            this.labelStat.Size = new System.Drawing.Size(276, 50);
            this.labelStat.TabIndex = 0;
            this.labelStat.Text = "Статистика";
            // 
            // panelWallets
            // 
            this.panelWallets.Controls.Add(this.panelWalletsElements);
            this.panelWallets.Controls.Add(this.labelWallets);
            this.panelWallets.Enabled = false;
            this.panelWallets.Location = new System.Drawing.Point(157, 50);
            this.panelWallets.Margin = new System.Windows.Forms.Padding(4);
            this.panelWallets.Name = "panelWallets";
            this.panelWallets.Size = new System.Drawing.Size(800, 453);
            this.panelWallets.TabIndex = 12;
            this.panelWallets.Visible = false;
            this.panelWallets.Paint += new System.Windows.Forms.PaintEventHandler(this.panelWallets_Paint);
            // 
            // panelWalletsElements
            // 
            this.panelWalletsElements.AutoScroll = true;
            this.panelWalletsElements.Controls.Add(this.groupBox3);
            this.panelWalletsElements.Controls.Add(this.groupBox2);
            this.panelWalletsElements.Controls.Add(this.groupBox1);
            this.panelWalletsElements.Controls.Add(this.Wallet1);
            this.panelWalletsElements.Location = new System.Drawing.Point(27, 68);
            this.panelWalletsElements.Margin = new System.Windows.Forms.Padding(4);
            this.panelWalletsElements.Name = "panelWalletsElements";
            this.panelWalletsElements.Size = new System.Drawing.Size(747, 357);
            this.panelWalletsElements.TabIndex = 5;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Location = new System.Drawing.Point(380, 12);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox3.Size = new System.Drawing.Size(167, 123);
            this.groupBox3.TabIndex = 4;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Кошелек 1";
            this.groupBox3.Visible = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(8, 32);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 16);
            this.label3.TabIndex = 0;
            this.label3.Text = "Баланс";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Location = new System.Drawing.Point(553, 12);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox2.Size = new System.Drawing.Size(167, 123);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Кошелек 1";
            this.groupBox2.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(8, 32);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 16);
            this.label2.TabIndex = 0;
            this.label2.Text = "Баланс";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(207, 12);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(167, 123);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Кошелек 1";
            this.groupBox1.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 32);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Баланс";
            // 
            // Wallet1
            // 
            this.Wallet1.Controls.Add(this.labelWalletAmount);
            this.Wallet1.Location = new System.Drawing.Point(33, 12);
            this.Wallet1.Margin = new System.Windows.Forms.Padding(4);
            this.Wallet1.Name = "Wallet1";
            this.Wallet1.Padding = new System.Windows.Forms.Padding(4);
            this.Wallet1.Size = new System.Drawing.Size(167, 123);
            this.Wallet1.TabIndex = 1;
            this.Wallet1.TabStop = false;
            this.Wallet1.Text = "Кошелек 1";
            this.Wallet1.Visible = false;
            this.Wallet1.Enter += new System.EventHandler(this.Wallet1_Enter);
            // 
            // labelWalletAmount
            // 
            this.labelWalletAmount.AutoSize = true;
            this.labelWalletAmount.Location = new System.Drawing.Point(8, 32);
            this.labelWalletAmount.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelWalletAmount.Name = "labelWalletAmount";
            this.labelWalletAmount.Size = new System.Drawing.Size(55, 16);
            this.labelWalletAmount.TabIndex = 0;
            this.labelWalletAmount.Text = "Баланс";
            // 
            // labelWallets
            // 
            this.labelWallets.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelWallets.Location = new System.Drawing.Point(312, 14);
            this.labelWallets.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelWallets.Name = "labelWallets";
            this.labelWallets.Size = new System.Drawing.Size(241, 50);
            this.labelWallets.TabIndex = 0;
            this.labelWallets.Text = "Кошельки";
            // 
            // panelProfile
            // 
            this.panelProfile.Controls.Add(this.labelProfileName);
            this.panelProfile.Controls.Add(this.labelProfile);
            this.panelProfile.Enabled = false;
            this.panelProfile.Location = new System.Drawing.Point(157, 50);
            this.panelProfile.Margin = new System.Windows.Forms.Padding(4);
            this.panelProfile.Name = "panelProfile";
            this.panelProfile.Size = new System.Drawing.Size(807, 453);
            this.panelProfile.TabIndex = 15;
            this.panelProfile.Visible = false;
            // 
            // labelProfileName
            // 
            this.labelProfileName.AutoSize = true;
            this.labelProfileName.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelProfileName.Location = new System.Drawing.Point(398, 79);
            this.labelProfileName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelProfileName.Name = "labelProfileName";
            this.labelProfileName.Size = new System.Drawing.Size(95, 29);
            this.labelProfileName.TabIndex = 1;
            this.labelProfileName.Text = "label10";
            // 
            // labelProfile
            // 
            this.labelProfile.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelProfile.Location = new System.Drawing.Point(283, 14);
            this.labelProfile.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelProfile.Name = "labelProfile";
            this.labelProfile.Size = new System.Drawing.Size(331, 50);
            this.labelProfile.TabIndex = 0;
            this.labelProfile.Text = "Ваш профиль";
            // 
            // buttonAdmin
            // 
            this.buttonAdmin.Location = new System.Drawing.Point(20, 394);
            this.buttonAdmin.Margin = new System.Windows.Forms.Padding(4);
            this.buttonAdmin.Name = "buttonAdmin";
            this.buttonAdmin.Size = new System.Drawing.Size(133, 68);
            this.buttonAdmin.TabIndex = 16;
            this.buttonAdmin.Text = "Админ-панель";
            this.buttonAdmin.UseVisualStyleBackColor = true;
            this.buttonAdmin.Visible = false;
            this.buttonAdmin.Click += new System.EventHandler(this.buttonAdmin_Click);
            // 
            // panelAdmin
            // 
            this.panelAdmin.Controls.Add(this.buttonEdit);
            this.panelAdmin.Controls.Add(this.labelAdmin);
            this.panelAdmin.Controls.Add(this.dataGridViewUsers);
            this.panelAdmin.Enabled = false;
            this.panelAdmin.Location = new System.Drawing.Point(157, 50);
            this.panelAdmin.Margin = new System.Windows.Forms.Padding(4);
            this.panelAdmin.Name = "panelAdmin";
            this.panelAdmin.Size = new System.Drawing.Size(807, 453);
            this.panelAdmin.TabIndex = 17;
            this.panelAdmin.Visible = false;
            // 
            // buttonEdit
            // 
            this.buttonEdit.Location = new System.Drawing.Point(607, 387);
            this.buttonEdit.Margin = new System.Windows.Forms.Padding(4);
            this.buttonEdit.Name = "buttonEdit";
            this.buttonEdit.Size = new System.Drawing.Size(173, 47);
            this.buttonEdit.TabIndex = 2;
            this.buttonEdit.Text = "Сохранить";
            this.buttonEdit.UseVisualStyleBackColor = true;
            this.buttonEdit.Click += new System.EventHandler(this.buttonEdit_Click);
            // 
            // dataGridViewUsers
            // 
            this.dataGridViewUsers.AllowUserToAddRows = false;
            this.dataGridViewUsers.AllowUserToDeleteRows = false;
            this.dataGridViewUsers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewUsers.Location = new System.Drawing.Point(47, 79);
            this.dataGridViewUsers.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridViewUsers.Name = "dataGridViewUsers";
            this.dataGridViewUsers.RowHeadersWidth = 51;
            this.dataGridViewUsers.Size = new System.Drawing.Size(733, 300);
            this.dataGridViewUsers.TabIndex = 1;
            // 
            // labelAdmin
            // 
            this.labelAdmin.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelAdmin.Location = new System.Drawing.Point(283, 14);
            this.labelAdmin.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelAdmin.Name = "labelAdmin";
            this.labelAdmin.Size = new System.Drawing.Size(335, 50);
            this.labelAdmin.TabIndex = 0;
            this.labelAdmin.Text = "Админ-панель";
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1064, 544);
            this.Controls.Add(this.buttonProfile);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.buttonAdmin);
            this.Controls.Add(this.buttonMain);
            this.Controls.Add(this.buttonWallets);
            this.Controls.Add(this.buttonStat);
            this.Controls.Add(this.panelMain);
            this.Controls.Add(this.panelStat);
            this.Controls.Add(this.panelProfile);
            this.Controls.Add(this.panelWallets);
            this.Controls.Add(this.panelAdmin);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximumSize = new System.Drawing.Size(1082, 591);
            this.Name = "FormMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Учет финансов";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panelMain.ResumeLayout(false);
            this.panelWrites.ResumeLayout(false);
            this.Writes.ResumeLayout(false);
            this.Writes.PerformLayout();
            this.panelStat.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            this.panelWallets.ResumeLayout(false);
            this.panelWalletsElements.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.Wallet1.ResumeLayout(false);
            this.Wallet1.PerformLayout();
            this.panelProfile.ResumeLayout(false);
            this.panelProfile.PerformLayout();
            this.panelAdmin.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewUsers)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button buttonStat;
        private System.Windows.Forms.Button buttonWallets;
        private System.Windows.Forms.Button buttonProfile;
        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Button buttonMain;
        private System.Windows.Forms.Panel panelMain;
        private System.Windows.Forms.Label labelMain;
        private System.Windows.Forms.Button buttonAddTransaction;
        private System.Windows.Forms.GroupBox Writes;
        private System.Windows.Forms.Label labelWallet;
        private System.Windows.Forms.Label labelType;
        private System.Windows.Forms.Label labelCategory;
        private System.Windows.Forms.Label labelAmount;
        private System.Windows.Forms.Label labelDate;
        private System.Windows.Forms.Panel panelStat;
        private System.Windows.Forms.Label labelStat;
        private System.Windows.Forms.Panel panelWallets;
        private System.Windows.Forms.GroupBox Wallet1;
        private System.Windows.Forms.Label labelWalletAmount;
        private System.Windows.Forms.Label labelWallets;
        private System.Windows.Forms.Panel panelProfile;
        private System.Windows.Forms.Label labelProfile;
        private System.Windows.Forms.Label labelProfileName;
        private System.Windows.Forms.Button buttonAddWallet;
        private System.Windows.Forms.Button buttonAddCategory;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panelWalletsElements;
        private System.Windows.Forms.Panel panelWrites;
        private System.Windows.Forms.Button buttonAdmin;
        private System.Windows.Forms.Panel panelAdmin;
        private System.Windows.Forms.Label labelAdmin;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.DataGridView dataGridViewUsers;
        private System.Windows.Forms.Button buttonEdit;
    }
}

