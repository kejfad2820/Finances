﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinancesProject
{
    public partial class FormCategory : Form
    {
        public static int user_id;
        string[] types = new string[] { "Расход", "Доход" };
        static string relativePath = @"..\..\UsersDB.mdf";
        string connectionString = $@"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog = UsersDB.mdf;AttachDbFilename={Path.Combine(AppDomain.CurrentDomain.BaseDirectory, relativePath)};Integrated Security=True";

        public FormCategory(int id)
        {
            user_id = id;
            InitializeComponent();
            try
            {
                using(SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    conn.Close();
                }
                Debug.WriteLine("Success connection");
                comboBoxTypeOfCategory.Items.Clear();
                for(int i = 0; i < types.Length; i++)
                {
                    comboBoxTypeOfCategory.Items.Add(types[i].ToString());
                }
            }
            catch(Exception ex)
            {
                Debug.WriteLine(ex.Message);
            }
        }

        public void CreateCategory(string name, string type, int id)
        {
            using(SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                int type_id = 0;

                for(int i = 0; i < types.Length; i++)
                {
                    if(comboBoxTypeOfCategory.Text == types[i])
                    {
                        type_id = i;
                    }
                }

                string sql_category = "INSERT INTO Categories(Name, Type, User_id) VALUES(@name, @type_id, @user_id)";

                SqlCommand create_category = new SqlCommand(sql_category, conn);
                create_category.Parameters.AddWithValue("@name", name);
                create_category.Parameters.AddWithValue("@type_id", type_id);
                create_category.Parameters.AddWithValue("@user_id", user_id);

                create_category.ExecuteNonQuery();

                conn.Close();

                Debug.WriteLine("Success created the category");

                MessageBox.Show("Успешное создана категория", "Успешно", MessageBoxButtons.OK, MessageBoxIcon.Information);

                FormMain f2 = new FormMain(user_id);
                this.Hide();
                f2.ShowDialog();
                this.Close();

            }
        }

        private void FormCategory_Load(object sender, EventArgs e)
        {

        }

        private void buttonAddCategory_Click(object sender, EventArgs e)
        {
            CreateCategory(textNameOfCategory.Text, comboBoxTypeOfCategory.Text, user_id);
        }

        private void buttonBackCategory_Click(object sender, EventArgs e)
        {
            FormMain f2 = new FormMain(user_id);
            this.Hide();
            f2.ShowDialog();
            this.Close();
        }

        private void comboBoxTypeOfCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }
    }
}
