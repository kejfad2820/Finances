﻿using LiveCharts.Definitions.Charts;
using LiveCharts.Charts;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection.Emit;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using System.Windows.Markup;

namespace FinancesProject
{
    public partial class FormMain : Form
    {
        public int location_x_wallets = -105;
        public int location_y_wallets = 10;
        public int location_x_writes = -250;
        public int location_y_writes = 10;
        public static int user_id;
        public static string role_name;
        static string relativePath = @"..\..\UsersDB.mdf";
        string connectionString = $@"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog = UsersDB.mdf;AttachDbFilename={Path.Combine(AppDomain.CurrentDomain.BaseDirectory, relativePath)};Integrated Security=True";

        public void OpenWindow(Panel panel)
        {
            panelWallets.Visible = false;
            panelWallets.Enabled = false;
            panelStat.Visible = false;
            panelStat.Enabled = false;
            panelMain.Visible = false;
            panelMain.Enabled = false;
            panelProfile.Enabled = false;
            panelProfile.Visible = false;
            panelAdmin.Enabled = false;
            panelAdmin.Visible = false;
            panel.Visible = true;
            panel.Enabled = true;
        }

        public FormMain(int id)
        {
            InitializeComponent();
            user_id = id;
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    Debug.WriteLine("Success connection");
                    OpenWindow(panelMain);
                    Debug.WriteLine("Main = " + user_id);
                }
                catch (SqlException ex)
                {
                    Debug.WriteLine(ex.Message);
                }
            }
            Show_Admin();
            Show_Writes();
        }

        public void Show_Admin()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                string sql_role = "SELECT ID_role FROM Users WHERE Id = @user_id";

                SqlCommand select_role = new SqlCommand(sql_role, conn);

                select_role.Parameters.AddWithValue("@user_id", user_id);

                int role_id = (int)select_role.ExecuteScalar();

                if(role_id == 2)
                {
                    buttonAdmin.Visible = true;
                }

                conn.Close();
            }
        }

        public void Show_Roles()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                string sql_roles = "SELECT Name FROM Roles";

                SqlCommand select_roles = new SqlCommand(sql_roles, conn);

                SqlDataReader reader = select_roles.ExecuteReader();

                comboBoxRole.Items.Clear();

                while (reader.Read())
                {
                    comboBoxRole.Items.Add(reader["Name"].ToString());
                }

                conn.Close();
            }
        }

        public void Show_Users()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                List<string> login = new List<string>();
                List<int> roles = new List<int>();
                List<string> roles_name = new List<string>();
                

                string sql_users = "SELECT Login FROM Users WHERE Id != @user_id";

                SqlCommand select_users = new SqlCommand(sql_users, conn);

                select_users.Parameters.AddWithValue("@user_id", user_id);

                SqlDataReader reader_users = select_users.ExecuteReader();

                string sql_roles = "SELECT ID_Role FROM Users WHERE Login = @login";

                SqlCommand select_role_id = new SqlCommand(sql_roles, conn);

                string sql_user_role = "SELECT Name FROM Roles WHERE Id = @role_id";

                SqlCommand select_role = new SqlCommand (sql_user_role, conn);

                comboBoxUsers.Items.Clear();

                login.Clear();

                while (reader_users.Read())
                {
                    string user = reader_users["Login"].ToString();
                    login.Add(user);
                }

                reader_users.Close();

                roles.Clear();

                for (int i = 0; i < login.Count; i++)
                {
                    select_role_id.Parameters.AddWithValue("@login", login[i]);
                    roles.Add((int)select_role_id.ExecuteScalar());
                }

                roles_name.Clear();

                for (int j = 0; j < roles.Count; j++)
                {
                    select_role.Parameters.AddWithValue("@role_id", roles[j]);

                    SqlDataReader reader = select_role.ExecuteReader();

                    while (reader.Read())
                    {
                        roles_name.Add(reader["Name"].ToString());
                    }
                    reader.Close();
                }

                for(int k = 0; k < roles.Count; k++)
                {
                    comboBoxUsers.Items.Add(login[k] + "(" + roles_name[k] + ")");
                }

                Debug.WriteLine(roles);

                conn.Close();
            }
        }

        public void Create_Wallet(string wallet_title, string balance, int i)
        {
            if(i == 0 || i == 4 || i == 8)
            {
                location_x_wallets = -105;
                if(i == 4 || i == 8)
                {
                    location_y_wallets += 105;
                }

            }
            //location_y_wallets += 105;
            location_x_wallets += 130;
            
            GroupBox groupBox = new GroupBox();
            panelWalletsElements.Controls.Add(groupBox);

            groupBox.Text = wallet_title;

            groupBox.Location = new Point(location_x_wallets, location_y_wallets);

            groupBox.Size = new Size(125, 100);

            System.Windows.Forms.Label labelBalance = new System.Windows.Forms.Label();
            groupBox.Controls.Add(labelBalance);
            labelBalance.Location = new Point(5, 25);
            labelBalance.Text = balance + " ₽";
            groupBox.Visible = true;

        }

        public void Show_Wallets()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                string sql_wallet = "SELECT Name, Amount FROM Wallets WHERE User_id = @user_id";

                SqlCommand select_wallet = new SqlCommand(sql_wallet, conn);

                select_wallet.Parameters.AddWithValue("@user_id", user_id);

                SqlDataReader reader = select_wallet.ExecuteReader();

                int i = 0;

                while (reader.Read())
                {
                    string wallet_name = reader["Name"].ToString();
                    float wallet_amount = Convert.ToSingle(reader["Amount"]);
                    Create_Wallet(reader["Name"].ToString(), wallet_amount.ToString(), i);
                    i++;
                }

                reader.Close();

                conn.Close();
            }
        }

        public void Create_Writes(string amount, string category_id, string type_id, string date, string wallet_id, int i)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                string category_name;
                string sql_category = "SELECT Name FROM Categories WHERE Id = @category_id";

                SqlCommand select_category = new SqlCommand(sql_category, conn);

                select_category.Parameters.AddWithValue("@category_id", category_id);

                SqlDataReader reader_category = select_category.ExecuteReader();

                reader_category.Read();

                category_name = reader_category["Name"].ToString();

                reader_category.Close();


                string wallet_name;
                string sql_wallet = "SELECT Name FROM Wallets WHERE Id = @wallet_id";

                SqlCommand select_wallet = new SqlCommand( sql_wallet, conn);

                select_wallet.Parameters.AddWithValue("@wallet_id", wallet_id);

                SqlDataReader reader_wallet = select_wallet.ExecuteReader();

                reader_wallet.Read();

                wallet_name = reader_wallet["Name"].ToString();
                reader_wallet.Close();

                string type_name;

                if(type_id == "0")
                {
                    type_name = "Расход";
                }
                else
                {
                    type_name = "Доход";
                }

                if (i == 0)
                {
                    location_x_writes = -250;
                    location_y_writes = 10;
                }
                else if (i == 2 || i == 4 || i == 6 || i == 8)
                {
                    location_x_writes = -250;
                    location_y_writes += 110;

                }
                location_x_writes += 270;

                GroupBox groupBox = new GroupBox();
                panelWrites.Controls.Add(groupBox);

                groupBox.Location = new Point(location_x_writes, location_y_writes);

                groupBox.Size = new Size(260, 100);

                System.Windows.Forms.Label labelAmount = new System.Windows.Forms.Label();
                System.Windows.Forms.Label labelCategory = new System.Windows.Forms.Label();
                System.Windows.Forms.Label labelType = new System.Windows.Forms.Label();
                System.Windows.Forms.Label labelWallet = new System.Windows.Forms.Label();
                System.Windows.Forms.Label labelDate = new System.Windows.Forms.Label();
                groupBox.Controls.Add(labelAmount);
                labelAmount.Location = new Point(20, 20);
                labelAmount.Text = amount + " ₽";
                groupBox.Text = category_name;
                groupBox.Controls.Add(labelType);
                labelType.Location = new Point(20, 70);
                labelType.Text = "Тип: " + type_name;
                groupBox.Controls.Add(labelWallet);
                labelWallet.Location = new Point(20, 45);
                labelWallet.Text = "Кошелек: " + wallet_name;
                groupBox.Controls.Add(labelDate);
                labelDate.Location = new Point(155, 70);
                labelDate.Text = "Дата: " + date;

                groupBox.BackColor = System.Drawing.Color.LightSlateGray;
                groupBox.FlatStyle = FlatStyle.Flat;
                groupBox.Visible = true;

                conn.Close();
            }
        }

        public void Show_Writes()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                string sql_wallet = "SELECT Amount, Category_id, Type_id, Date, Wallet_id FROM Transactions WHERE User_id = @user_id";

                SqlCommand select_wallet = new SqlCommand(sql_wallet, conn);

                select_wallet.Parameters.AddWithValue("@user_id", user_id);

                SqlDataReader reader = select_wallet.ExecuteReader();

                int i = 0;

                while (reader.Read())
                {
                    Create_Writes(reader["Amount"].ToString(), reader["Category_id"].ToString(), reader["Type_id"].ToString(), reader["Date"].ToString(), reader["Wallet_id"].ToString(), i);
                    i++;
                }

                reader.Close();

                conn.Close();
            }
        }

        public void Show_Profile()
        {
            using(SqlConnection conn = new SqlConnection(connectionString))
            {
                string profile_name;
                conn.Open();

                string sql_profile = "SELECT Login FROM Users WHERE Id = @user_id";

                SqlCommand select_profile = new SqlCommand(sql_profile, conn);

                select_profile.Parameters.AddWithValue("@user_id", user_id);

                SqlDataReader reader_profile = select_profile.ExecuteReader();

                reader_profile.Read();

                profile_name = reader_profile["Login"].ToString();

                reader_profile.Close();

                labelProfileName.Text = profile_name.ToString();

                conn.Close();
            }
        }

        public void Edit_Roles()
        {
            using( SqlConnection conn = new SqlConnection( connectionString))
            {
                string login = comboBoxUsers.Text;
                string role_edit = comboBoxRole.Text;

                conn.Open();

                string sql_role_id = "SELECT Id FROM Roles WHERE Name = @role_edit";

                SqlCommand select_role_id = new SqlCommand(sql_role_id, conn);

                select_role_id.Parameters.AddWithValue("@role_edit", role_edit);

                int role_id = (int)select_role_id.ExecuteScalar();

                int index = login.IndexOf("(");
                if (index != -1)
                {
                    login = login.Substring(0, index);
                }

                string sql_role = "UPDATE Users SET ID_role = @role_id WHERE Login = @login";
                SqlCommand update_role = new SqlCommand(sql_role, conn);

                update_role.Parameters.AddWithValue("@login", login);
                update_role.Parameters.AddWithValue("@role_id", role_id);

                update_role.ExecuteNonQuery();

                MessageBox.Show("Успешная смена роли", "Успешно", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Show_Roles();
                Show_Users();

                conn.Close();
            }
        }

        private void buttonProfile_Click(object sender, EventArgs e)
        {
            OpenWindow(panelProfile);

            Show_Profile();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void buttonMain_Click(object sender, EventArgs e)
        {
            OpenWindow(panelMain);
            panelWrites.Controls.Clear();
            Show_Writes();
            location_x_writes = -250;
            location_y_writes = 10;

        }

        public void Show_Stat()
        {
            using(SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                List<int> categories_id = new List<int>();
                List<float> transactions = new List<float>();
                List<string> categories = new List<string>();
                float amount = 0;
                chart1.Series.Clear();
                chart1.Series.Add("value");
                chart1.Series[0].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Pie;

                string sql_categories_id = "SELECT Id FROM Categories WHERE User_id = @user_id";

                SqlCommand select_categories_id = new SqlCommand(sql_categories_id, conn);

                select_categories_id.Parameters.AddWithValue("@user_id", user_id);

                SqlDataReader reader_categories_id = select_categories_id.ExecuteReader();

                categories_id.Clear();

                while (reader_categories_id.Read())
                {
                    categories_id.Add((int)reader_categories_id["Id"]);
                }
                reader_categories_id.Close();

                string sql_transactions = "SELECT Amount FROM Transactions WHERE Category_id = @category_id";

                SqlCommand select_transactions = new SqlCommand(sql_transactions, conn);

                transactions.Clear();

                for (int i = 0; i < categories_id.Count; i++)
                {
                    if(categories_id[i] != null)
                    {
                        select_transactions.Parameters.AddWithValue("@category_id", categories_id[i]);

                        SqlDataReader reader_transactions = select_transactions.ExecuteReader();

                        amount = 0;

                        while (reader_transactions.Read())
                        {
                            if (reader_transactions["Amount"] != DBNull.Value || reader_transactions["Amount"] != null)
                            {
                                amount += Convert.ToSingle(reader_transactions["Amount"]);
                                Debug.WriteLine(reader_transactions["Amount"]);
                            }
                            else
                            {
                                reader_transactions.Close();
                            }
                        }
                        transactions.Add(amount);
                        reader_transactions.Close();
                        select_transactions.Parameters.Clear();
                    }
                    else
                    {
                        break;
                    }

                    string sql_categories = "SELECT Name FROM Categories WHERE Id = @category_id";

                    SqlCommand select_category = new SqlCommand(sql_categories, conn);

                    select_category.Parameters.AddWithValue("@category_id", categories_id[i]);

                    SqlDataReader reader_categories = select_category.ExecuteReader();

                    //categories.Clear();

                    while (reader_categories.Read())
                    {
                        categories.Add(reader_categories["Name"].ToString());
                    }

                    reader_categories.Close();

                    chart1.Series[0].Points.Add(transactions[i]);
                    chart1.Series[0].Points[i].LegendText = categories[i].ToString();
                    chart1.Series[0].Points[i].Label = transactions[i].ToString() + " ₽";

                    select_category.Parameters.Clear();

                }
                conn.Close();
            }
        }

        private void buttonStat_Click(object sender, EventArgs e)
        {
            OpenWindow(panelStat);

            Show_Stat();
        }

        private void buttonWallets_Click(object sender, EventArgs e)
        {
            OpenWindow(panelWallets);
            panelWalletsElements.Controls.Clear();
            Show_Wallets();
            location_x_wallets = -105;
            location_y_wallets = 10;
        }

        private void panelMain_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panelExpenses_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Expense1_Enter(object sender, EventArgs e)
        {

        }

        private void buttonAddExpense_Click(object sender, EventArgs e)
        {

        }

        private void panelIncomes_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Income1_Enter(object sender, EventArgs e)
        {

        }

        private void buttonAddIncome_Click(object sender, EventArgs e)
        {

        }

        private void panelWallets_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Wallet1_Enter(object sender, EventArgs e)
        {

        }

        private void panelStat_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void buttonAddTransaction_Click(object sender, EventArgs e)
        {
            FormData f3 = new FormData(user_id);
            this.Hide();
            f3.ShowDialog();
            this.Close();
        }

        private void buttonAddCategory_Click(object sender, EventArgs e)
        {
            FormCategory f4 = new FormCategory(user_id);
            this.Hide();
            f4.ShowDialog();
            this.Close();
        }

        private void buttonAddWallet_Click(object sender, EventArgs e)
        {
            FormWallet f5 = new FormWallet(user_id);
            this.Hide();
            f5.ShowDialog();
            this.Close();
        }

        private void buttonAdmin_Click(object sender, EventArgs e)
        {
            OpenWindow(panelAdmin);

            Show_Users();
            Show_Roles();
        }

        private void buttonEditRole_Click(object sender, EventArgs e)
        {
            Edit_Roles();
        }
    }
}
