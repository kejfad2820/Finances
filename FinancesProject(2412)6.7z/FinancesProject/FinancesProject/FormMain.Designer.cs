﻿namespace FinancesProject
{
    partial class FormMain
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea3 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend3 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.buttonStat = new System.Windows.Forms.Button();
            this.buttonWallets = new System.Windows.Forms.Button();
            this.buttonProfile = new System.Windows.Forms.Button();
            this.buttonExit = new System.Windows.Forms.Button();
            this.buttonMain = new System.Windows.Forms.Button();
            this.panelMain = new System.Windows.Forms.Panel();
            this.panelWrites = new System.Windows.Forms.Panel();
            this.Writes = new System.Windows.Forms.GroupBox();
            this.labelDate = new System.Windows.Forms.Label();
            this.labelWallet = new System.Windows.Forms.Label();
            this.labelType = new System.Windows.Forms.Label();
            this.labelCategory = new System.Windows.Forms.Label();
            this.labelAmount = new System.Windows.Forms.Label();
            this.buttonAddTransaction = new System.Windows.Forms.Button();
            this.buttonAddCategory = new System.Windows.Forms.Button();
            this.buttonAddWallet = new System.Windows.Forms.Button();
            this.labelMain = new System.Windows.Forms.Label();
            this.panelStat = new System.Windows.Forms.Panel();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.labelStat = new System.Windows.Forms.Label();
            this.panelWallets = new System.Windows.Forms.Panel();
            this.panelWalletsElements = new System.Windows.Forms.Panel();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Wallet1 = new System.Windows.Forms.GroupBox();
            this.labelWalletAmount = new System.Windows.Forms.Label();
            this.labelWallets = new System.Windows.Forms.Label();
            this.panelProfile = new System.Windows.Forms.Panel();
            this.labelProfileName = new System.Windows.Forms.Label();
            this.labelProfile = new System.Windows.Forms.Label();
            this.buttonAdmin = new System.Windows.Forms.Button();
            this.panelAdmin = new System.Windows.Forms.Panel();
            this.comboBoxRole = new System.Windows.Forms.ComboBox();
            this.labelUsersAdmin = new System.Windows.Forms.Label();
            this.buttonEditRole = new System.Windows.Forms.Button();
            this.labelRoleAdmin = new System.Windows.Forms.Label();
            this.comboBoxUsers = new System.Windows.Forms.ComboBox();
            this.labelAdmin = new System.Windows.Forms.Label();
            this.panelMain.SuspendLayout();
            this.panelWrites.SuspendLayout();
            this.Writes.SuspendLayout();
            this.panelStat.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            this.panelWallets.SuspendLayout();
            this.panelWalletsElements.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.Wallet1.SuspendLayout();
            this.panelProfile.SuspendLayout();
            this.panelAdmin.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonStat
            // 
            this.buttonStat.Location = new System.Drawing.Point(15, 200);
            this.buttonStat.Name = "buttonStat";
            this.buttonStat.Size = new System.Drawing.Size(100, 55);
            this.buttonStat.TabIndex = 2;
            this.buttonStat.Text = "Статистика";
            this.buttonStat.UseVisualStyleBackColor = true;
            this.buttonStat.Click += new System.EventHandler(this.buttonStat_Click);
            // 
            // buttonWallets
            // 
            this.buttonWallets.Location = new System.Drawing.Point(15, 260);
            this.buttonWallets.Name = "buttonWallets";
            this.buttonWallets.Size = new System.Drawing.Size(100, 55);
            this.buttonWallets.TabIndex = 3;
            this.buttonWallets.Text = "Кошельки";
            this.buttonWallets.UseVisualStyleBackColor = true;
            this.buttonWallets.Click += new System.EventHandler(this.buttonWallets_Click);
            // 
            // buttonProfile
            // 
            this.buttonProfile.Location = new System.Drawing.Point(713, 12);
            this.buttonProfile.Name = "buttonProfile";
            this.buttonProfile.Size = new System.Drawing.Size(75, 23);
            this.buttonProfile.TabIndex = 4;
            this.buttonProfile.Text = "Профиль";
            this.buttonProfile.UseVisualStyleBackColor = true;
            this.buttonProfile.Click += new System.EventHandler(this.buttonProfile_Click);
            // 
            // buttonExit
            // 
            this.buttonExit.Location = new System.Drawing.Point(713, 415);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(75, 23);
            this.buttonExit.TabIndex = 5;
            this.buttonExit.Text = "Выйти";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // buttonMain
            // 
            this.buttonMain.Location = new System.Drawing.Point(15, 140);
            this.buttonMain.Name = "buttonMain";
            this.buttonMain.Size = new System.Drawing.Size(100, 55);
            this.buttonMain.TabIndex = 6;
            this.buttonMain.Text = "Главная";
            this.buttonMain.UseVisualStyleBackColor = true;
            this.buttonMain.Click += new System.EventHandler(this.buttonMain_Click);
            // 
            // panelMain
            // 
            this.panelMain.Controls.Add(this.panelWrites);
            this.panelMain.Controls.Add(this.buttonAddTransaction);
            this.panelMain.Controls.Add(this.buttonAddCategory);
            this.panelMain.Controls.Add(this.buttonAddWallet);
            this.panelMain.Controls.Add(this.labelMain);
            this.panelMain.Enabled = false;
            this.panelMain.Location = new System.Drawing.Point(118, 41);
            this.panelMain.Name = "panelMain";
            this.panelMain.Size = new System.Drawing.Size(600, 368);
            this.panelMain.TabIndex = 7;
            this.panelMain.Visible = false;
            this.panelMain.Paint += new System.Windows.Forms.PaintEventHandler(this.panelMain_Paint);
            // 
            // panelWrites
            // 
            this.panelWrites.AutoScroll = true;
            this.panelWrites.Controls.Add(this.Writes);
            this.panelWrites.Location = new System.Drawing.Point(15, 50);
            this.panelWrites.Name = "panelWrites";
            this.panelWrites.Size = new System.Drawing.Size(570, 258);
            this.panelWrites.TabIndex = 6;
            // 
            // Writes
            // 
            this.Writes.BackColor = System.Drawing.Color.LightSlateGray;
            this.Writes.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Writes.Controls.Add(this.labelDate);
            this.Writes.Controls.Add(this.labelWallet);
            this.Writes.Controls.Add(this.labelType);
            this.Writes.Controls.Add(this.labelCategory);
            this.Writes.Controls.Add(this.labelAmount);
            this.Writes.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.Writes.Location = new System.Drawing.Point(20, 10);
            this.Writes.Name = "Writes";
            this.Writes.Size = new System.Drawing.Size(260, 100);
            this.Writes.TabIndex = 3;
            this.Writes.TabStop = false;
            this.Writes.Text = "Запись 1";
            this.Writes.Visible = false;
            // 
            // labelDate
            // 
            this.labelDate.AutoSize = true;
            this.labelDate.Location = new System.Drawing.Point(160, 70);
            this.labelDate.Name = "labelDate";
            this.labelDate.Size = new System.Drawing.Size(33, 13);
            this.labelDate.TabIndex = 4;
            this.labelDate.Text = "Дата";
            // 
            // labelWallet
            // 
            this.labelWallet.AutoSize = true;
            this.labelWallet.Location = new System.Drawing.Point(160, 45);
            this.labelWallet.Name = "labelWallet";
            this.labelWallet.Size = new System.Drawing.Size(52, 13);
            this.labelWallet.TabIndex = 3;
            this.labelWallet.Text = "Кошелек";
            // 
            // labelType
            // 
            this.labelType.AutoSize = true;
            this.labelType.Location = new System.Drawing.Point(20, 70);
            this.labelType.Name = "labelType";
            this.labelType.Size = new System.Drawing.Size(26, 13);
            this.labelType.TabIndex = 2;
            this.labelType.Text = "Тип";
            // 
            // labelCategory
            // 
            this.labelCategory.AutoSize = true;
            this.labelCategory.Location = new System.Drawing.Point(20, 45);
            this.labelCategory.Name = "labelCategory";
            this.labelCategory.Size = new System.Drawing.Size(60, 13);
            this.labelCategory.TabIndex = 1;
            this.labelCategory.Text = "Категория";
            // 
            // labelAmount
            // 
            this.labelAmount.AutoSize = true;
            this.labelAmount.Location = new System.Drawing.Point(20, 20);
            this.labelAmount.Name = "labelAmount";
            this.labelAmount.Size = new System.Drawing.Size(41, 13);
            this.labelAmount.TabIndex = 0;
            this.labelAmount.Text = "Сумма";
            // 
            // buttonAddTransaction
            // 
            this.buttonAddTransaction.Location = new System.Drawing.Point(146, 317);
            this.buttonAddTransaction.Name = "buttonAddTransaction";
            this.buttonAddTransaction.Size = new System.Drawing.Size(104, 48);
            this.buttonAddTransaction.TabIndex = 1;
            this.buttonAddTransaction.Text = "Добавить транзакцию";
            this.buttonAddTransaction.UseVisualStyleBackColor = true;
            this.buttonAddTransaction.Click += new System.EventHandler(this.buttonAddTransaction_Click);
            // 
            // buttonAddCategory
            // 
            this.buttonAddCategory.Location = new System.Drawing.Point(256, 317);
            this.buttonAddCategory.Name = "buttonAddCategory";
            this.buttonAddCategory.Size = new System.Drawing.Size(104, 48);
            this.buttonAddCategory.TabIndex = 4;
            this.buttonAddCategory.Text = "Добавить категорию";
            this.buttonAddCategory.UseVisualStyleBackColor = true;
            this.buttonAddCategory.Click += new System.EventHandler(this.buttonAddCategory_Click);
            // 
            // buttonAddWallet
            // 
            this.buttonAddWallet.Location = new System.Drawing.Point(366, 317);
            this.buttonAddWallet.Name = "buttonAddWallet";
            this.buttonAddWallet.Size = new System.Drawing.Size(104, 48);
            this.buttonAddWallet.TabIndex = 5;
            this.buttonAddWallet.Text = "Добавить кошелек";
            this.buttonAddWallet.UseVisualStyleBackColor = true;
            this.buttonAddWallet.Click += new System.EventHandler(this.buttonAddWallet_Click);
            // 
            // labelMain
            // 
            this.labelMain.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelMain.Location = new System.Drawing.Point(217, 11);
            this.labelMain.Name = "labelMain";
            this.labelMain.Size = new System.Drawing.Size(153, 41);
            this.labelMain.TabIndex = 0;
            this.labelMain.Text = "Главная";
            // 
            // panelStat
            // 
            this.panelStat.Controls.Add(this.chart1);
            this.panelStat.Controls.Add(this.labelStat);
            this.panelStat.Enabled = false;
            this.panelStat.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.panelStat.Location = new System.Drawing.Point(118, 41);
            this.panelStat.Name = "panelStat";
            this.panelStat.Size = new System.Drawing.Size(605, 368);
            this.panelStat.TabIndex = 10;
            this.panelStat.Visible = false;
            this.panelStat.Paint += new System.Windows.Forms.PaintEventHandler(this.panelStat_Paint);
            // 
            // chart1
            // 
            chartArea3.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea3);
            this.chart1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            legend3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            legend3.IsTextAutoFit = false;
            legend3.Name = "Legend1";
            legend3.TableStyle = System.Windows.Forms.DataVisualization.Charting.LegendTableStyle.Tall;
            this.chart1.Legends.Add(legend3);
            this.chart1.Location = new System.Drawing.Point(77, 55);
            this.chart1.Name = "chart1";
            series3.ChartArea = "ChartArea1";
            series3.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Pie;
            series3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            series3.Legend = "Legend1";
            series3.Name = "Series1";
            this.chart1.Series.Add(series3);
            this.chart1.Size = new System.Drawing.Size(459, 300);
            this.chart1.TabIndex = 1;
            // 
            // labelStat
            // 
            this.labelStat.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelStat.Location = new System.Drawing.Point(195, 11);
            this.labelStat.Name = "labelStat";
            this.labelStat.Size = new System.Drawing.Size(207, 41);
            this.labelStat.TabIndex = 0;
            this.labelStat.Text = "Статистика";
            // 
            // panelWallets
            // 
            this.panelWallets.Controls.Add(this.panelWalletsElements);
            this.panelWallets.Controls.Add(this.labelWallets);
            this.panelWallets.Enabled = false;
            this.panelWallets.Location = new System.Drawing.Point(118, 41);
            this.panelWallets.Name = "panelWallets";
            this.panelWallets.Size = new System.Drawing.Size(600, 368);
            this.panelWallets.TabIndex = 12;
            this.panelWallets.Visible = false;
            this.panelWallets.Paint += new System.Windows.Forms.PaintEventHandler(this.panelWallets_Paint);
            // 
            // panelWalletsElements
            // 
            this.panelWalletsElements.AutoScroll = true;
            this.panelWalletsElements.Controls.Add(this.groupBox3);
            this.panelWalletsElements.Controls.Add(this.groupBox2);
            this.panelWalletsElements.Controls.Add(this.groupBox1);
            this.panelWalletsElements.Controls.Add(this.Wallet1);
            this.panelWalletsElements.Location = new System.Drawing.Point(20, 55);
            this.panelWalletsElements.Name = "panelWalletsElements";
            this.panelWalletsElements.Size = new System.Drawing.Size(560, 290);
            this.panelWalletsElements.TabIndex = 5;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Location = new System.Drawing.Point(285, 10);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(125, 100);
            this.groupBox3.TabIndex = 4;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Кошелек 1";
            this.groupBox3.Visible = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 26);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Баланс";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Location = new System.Drawing.Point(415, 10);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(125, 100);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Кошелек 1";
            this.groupBox2.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Баланс";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(155, 10);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(125, 100);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Кошелек 1";
            this.groupBox1.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Баланс";
            // 
            // Wallet1
            // 
            this.Wallet1.Controls.Add(this.labelWalletAmount);
            this.Wallet1.Location = new System.Drawing.Point(25, 10);
            this.Wallet1.Name = "Wallet1";
            this.Wallet1.Size = new System.Drawing.Size(125, 100);
            this.Wallet1.TabIndex = 1;
            this.Wallet1.TabStop = false;
            this.Wallet1.Text = "Кошелек 1";
            this.Wallet1.Visible = false;
            this.Wallet1.Enter += new System.EventHandler(this.Wallet1_Enter);
            // 
            // labelWalletAmount
            // 
            this.labelWalletAmount.AutoSize = true;
            this.labelWalletAmount.Location = new System.Drawing.Point(6, 26);
            this.labelWalletAmount.Name = "labelWalletAmount";
            this.labelWalletAmount.Size = new System.Drawing.Size(44, 13);
            this.labelWalletAmount.TabIndex = 0;
            this.labelWalletAmount.Text = "Баланс";
            // 
            // labelWallets
            // 
            this.labelWallets.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelWallets.Location = new System.Drawing.Point(215, 11);
            this.labelWallets.Name = "labelWallets";
            this.labelWallets.Size = new System.Drawing.Size(181, 41);
            this.labelWallets.TabIndex = 0;
            this.labelWallets.Text = "Кошельки";
            // 
            // panelProfile
            // 
            this.panelProfile.Controls.Add(this.labelProfileName);
            this.panelProfile.Controls.Add(this.labelProfile);
            this.panelProfile.Enabled = false;
            this.panelProfile.Location = new System.Drawing.Point(118, 41);
            this.panelProfile.Name = "panelProfile";
            this.panelProfile.Size = new System.Drawing.Size(605, 368);
            this.panelProfile.TabIndex = 15;
            this.panelProfile.Visible = false;
            // 
            // labelProfileName
            // 
            this.labelProfileName.AutoSize = true;
            this.labelProfileName.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelProfileName.Location = new System.Drawing.Point(251, 66);
            this.labelProfileName.Name = "labelProfileName";
            this.labelProfileName.Size = new System.Drawing.Size(75, 25);
            this.labelProfileName.TabIndex = 1;
            this.labelProfileName.Text = "label10";
            // 
            // labelProfile
            // 
            this.labelProfile.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelProfile.Location = new System.Drawing.Point(178, 11);
            this.labelProfile.Name = "labelProfile";
            this.labelProfile.Size = new System.Drawing.Size(248, 41);
            this.labelProfile.TabIndex = 0;
            this.labelProfile.Text = "Ваш профиль";
            // 
            // buttonAdmin
            // 
            this.buttonAdmin.Location = new System.Drawing.Point(15, 320);
            this.buttonAdmin.Name = "buttonAdmin";
            this.buttonAdmin.Size = new System.Drawing.Size(100, 55);
            this.buttonAdmin.TabIndex = 16;
            this.buttonAdmin.Text = "Админ-панель";
            this.buttonAdmin.UseVisualStyleBackColor = true;
            this.buttonAdmin.Visible = false;
            this.buttonAdmin.Click += new System.EventHandler(this.buttonAdmin_Click);
            // 
            // panelAdmin
            // 
            this.panelAdmin.Controls.Add(this.comboBoxRole);
            this.panelAdmin.Controls.Add(this.labelUsersAdmin);
            this.panelAdmin.Controls.Add(this.buttonEditRole);
            this.panelAdmin.Controls.Add(this.labelRoleAdmin);
            this.panelAdmin.Controls.Add(this.comboBoxUsers);
            this.panelAdmin.Controls.Add(this.labelAdmin);
            this.panelAdmin.Enabled = false;
            this.panelAdmin.Location = new System.Drawing.Point(118, 41);
            this.panelAdmin.Name = "panelAdmin";
            this.panelAdmin.Size = new System.Drawing.Size(605, 368);
            this.panelAdmin.TabIndex = 17;
            this.panelAdmin.Visible = false;
            // 
            // comboBoxRole
            // 
            this.comboBoxRole.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxRole.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.comboBoxRole.FormattingEnabled = true;
            this.comboBoxRole.Location = new System.Drawing.Point(221, 126);
            this.comboBoxRole.Name = "comboBoxRole";
            this.comboBoxRole.Size = new System.Drawing.Size(175, 28);
            this.comboBoxRole.TabIndex = 6;
            // 
            // labelUsersAdmin
            // 
            this.labelUsersAdmin.AutoSize = true;
            this.labelUsersAdmin.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.labelUsersAdmin.Location = new System.Drawing.Point(86, 97);
            this.labelUsersAdmin.Name = "labelUsersAdmin";
            this.labelUsersAdmin.Size = new System.Drawing.Size(129, 22);
            this.labelUsersAdmin.TabIndex = 5;
            this.labelUsersAdmin.Text = "Пользователи";
            // 
            // buttonEditRole
            // 
            this.buttonEditRole.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.buttonEditRole.Location = new System.Drawing.Point(231, 165);
            this.buttonEditRole.Name = "buttonEditRole";
            this.buttonEditRole.Size = new System.Drawing.Size(157, 38);
            this.buttonEditRole.TabIndex = 4;
            this.buttonEditRole.Text = "Изменить роль";
            this.buttonEditRole.UseVisualStyleBackColor = true;
            this.buttonEditRole.Click += new System.EventHandler(this.buttonEditRole_Click);
            // 
            // labelRoleAdmin
            // 
            this.labelRoleAdmin.AutoSize = true;
            this.labelRoleAdmin.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.labelRoleAdmin.Location = new System.Drawing.Point(164, 132);
            this.labelRoleAdmin.Name = "labelRoleAdmin";
            this.labelRoleAdmin.Size = new System.Drawing.Size(51, 22);
            this.labelRoleAdmin.TabIndex = 2;
            this.labelRoleAdmin.Text = "Роль";
            // 
            // comboBoxUsers
            // 
            this.comboBoxUsers.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxUsers.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.comboBoxUsers.FormattingEnabled = true;
            this.comboBoxUsers.Location = new System.Drawing.Point(221, 91);
            this.comboBoxUsers.Name = "comboBoxUsers";
            this.comboBoxUsers.Size = new System.Drawing.Size(175, 28);
            this.comboBoxUsers.TabIndex = 1;
            // 
            // labelAdmin
            // 
            this.labelAdmin.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelAdmin.Location = new System.Drawing.Point(195, 11);
            this.labelAdmin.Name = "labelAdmin";
            this.labelAdmin.Size = new System.Drawing.Size(251, 41);
            this.labelAdmin.TabIndex = 0;
            this.labelAdmin.Text = "Админ-панель";
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panelMain);
            this.Controls.Add(this.panelStat);
            this.Controls.Add(this.panelAdmin);
            this.Controls.Add(this.buttonAdmin);
            this.Controls.Add(this.buttonMain);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.buttonProfile);
            this.Controls.Add(this.buttonWallets);
            this.Controls.Add(this.buttonStat);
            this.Controls.Add(this.panelProfile);
            this.Controls.Add(this.panelWallets);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximumSize = new System.Drawing.Size(816, 489);
            this.Name = "FormMain";
            this.Text = "Учет финансов";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panelMain.ResumeLayout(false);
            this.panelWrites.ResumeLayout(false);
            this.Writes.ResumeLayout(false);
            this.Writes.PerformLayout();
            this.panelStat.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            this.panelWallets.ResumeLayout(false);
            this.panelWalletsElements.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.Wallet1.ResumeLayout(false);
            this.Wallet1.PerformLayout();
            this.panelProfile.ResumeLayout(false);
            this.panelProfile.PerformLayout();
            this.panelAdmin.ResumeLayout(false);
            this.panelAdmin.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button buttonStat;
        private System.Windows.Forms.Button buttonWallets;
        private System.Windows.Forms.Button buttonProfile;
        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Button buttonMain;
        private System.Windows.Forms.Panel panelMain;
        private System.Windows.Forms.Label labelMain;
        private System.Windows.Forms.Button buttonAddTransaction;
        private System.Windows.Forms.GroupBox Writes;
        private System.Windows.Forms.Label labelWallet;
        private System.Windows.Forms.Label labelType;
        private System.Windows.Forms.Label labelCategory;
        private System.Windows.Forms.Label labelAmount;
        private System.Windows.Forms.Label labelDate;
        private System.Windows.Forms.Panel panelStat;
        private System.Windows.Forms.Label labelStat;
        private System.Windows.Forms.Panel panelWallets;
        private System.Windows.Forms.GroupBox Wallet1;
        private System.Windows.Forms.Label labelWalletAmount;
        private System.Windows.Forms.Label labelWallets;
        private System.Windows.Forms.Panel panelProfile;
        private System.Windows.Forms.Label labelProfile;
        private System.Windows.Forms.Label labelProfileName;
        private System.Windows.Forms.Button buttonAddWallet;
        private System.Windows.Forms.Button buttonAddCategory;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panelWalletsElements;
        private System.Windows.Forms.Panel panelWrites;
        private System.Windows.Forms.Button buttonAdmin;
        private System.Windows.Forms.Panel panelAdmin;
        private System.Windows.Forms.Label labelAdmin;
        private System.Windows.Forms.Label labelRoleAdmin;
        private System.Windows.Forms.ComboBox comboBoxUsers;
        private System.Windows.Forms.Button buttonEditRole;
        private System.Windows.Forms.Label labelUsersAdmin;
        private System.Windows.Forms.ComboBox comboBoxRole;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
    }
}

