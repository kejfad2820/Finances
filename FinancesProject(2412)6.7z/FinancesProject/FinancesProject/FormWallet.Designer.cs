﻿namespace FinancesProject
{
    partial class FormWallet
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonBackWallet = new System.Windows.Forms.Button();
            this.buttonAddWallet = new System.Windows.Forms.Button();
            this.labelBalanceOfWallet = new System.Windows.Forms.Label();
            this.labelNameOfWallet = new System.Windows.Forms.Label();
            this.textBalanceOfWallet = new System.Windows.Forms.TextBox();
            this.textNameOfWallet = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // buttonBackWallet
            // 
            this.buttonBackWallet.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonBackWallet.Location = new System.Drawing.Point(379, 325);
            this.buttonBackWallet.Name = "buttonBackWallet";
            this.buttonBackWallet.Size = new System.Drawing.Size(100, 31);
            this.buttonBackWallet.TabIndex = 32;
            this.buttonBackWallet.Text = "Назад";
            this.buttonBackWallet.UseVisualStyleBackColor = true;
            this.buttonBackWallet.Click += new System.EventHandler(this.buttonBackWallet_Click);
            // 
            // buttonAddWallet
            // 
            this.buttonAddWallet.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonAddWallet.Location = new System.Drawing.Point(199, 215);
            this.buttonAddWallet.Name = "buttonAddWallet";
            this.buttonAddWallet.Size = new System.Drawing.Size(100, 31);
            this.buttonAddWallet.TabIndex = 31;
            this.buttonAddWallet.Text = "Добавить";
            this.buttonAddWallet.UseVisualStyleBackColor = true;
            this.buttonAddWallet.Click += new System.EventHandler(this.buttonAddWallet_Click);
            // 
            // labelBalanceOfWallet
            // 
            this.labelBalanceOfWallet.AutoSize = true;
            this.labelBalanceOfWallet.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.labelBalanceOfWallet.Location = new System.Drawing.Point(70, 134);
            this.labelBalanceOfWallet.Name = "labelBalanceOfWallet";
            this.labelBalanceOfWallet.Size = new System.Drawing.Size(71, 22);
            this.labelBalanceOfWallet.TabIndex = 25;
            this.labelBalanceOfWallet.Text = "Баланс";
            // 
            // labelNameOfWallet
            // 
            this.labelNameOfWallet.AutoSize = true;
            this.labelNameOfWallet.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.labelNameOfWallet.Location = new System.Drawing.Point(49, 101);
            this.labelNameOfWallet.Name = "labelNameOfWallet";
            this.labelNameOfWallet.Size = new System.Drawing.Size(92, 22);
            this.labelNameOfWallet.TabIndex = 23;
            this.labelNameOfWallet.Text = "Название";
            // 
            // textBalanceOfWallet
            // 
            this.textBalanceOfWallet.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBalanceOfWallet.Location = new System.Drawing.Point(147, 129);
            this.textBalanceOfWallet.Name = "textBalanceOfWallet";
            this.textBalanceOfWallet.Size = new System.Drawing.Size(205, 27);
            this.textBalanceOfWallet.TabIndex = 20;
            // 
            // textNameOfWallet
            // 
            this.textNameOfWallet.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textNameOfWallet.Location = new System.Drawing.Point(147, 96);
            this.textNameOfWallet.Name = "textNameOfWallet";
            this.textNameOfWallet.Size = new System.Drawing.Size(205, 27);
            this.textNameOfWallet.TabIndex = 19;
            // 
            // FormWallet
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(484, 361);
            this.Controls.Add(this.buttonBackWallet);
            this.Controls.Add(this.buttonAddWallet);
            this.Controls.Add(this.labelBalanceOfWallet);
            this.Controls.Add(this.labelNameOfWallet);
            this.Controls.Add(this.textBalanceOfWallet);
            this.Controls.Add(this.textNameOfWallet);
            this.Name = "FormWallet";
            this.Text = "Создание кошелька";
            this.Load += new System.EventHandler(this.FormWallet_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonBackWallet;
        private System.Windows.Forms.Button buttonAddWallet;
        private System.Windows.Forms.Label labelBalanceOfWallet;
        private System.Windows.Forms.Label labelNameOfWallet;
        private System.Windows.Forms.TextBox textBalanceOfWallet;
        private System.Windows.Forms.TextBox textNameOfWallet;
    }
}