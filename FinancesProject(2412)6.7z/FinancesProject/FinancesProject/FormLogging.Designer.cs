﻿namespace FinancesProject
{
    partial class FormLogging
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelRegistration = new System.Windows.Forms.Panel();
            this.labelPassReg = new System.Windows.Forms.Label();
            this.labelMailReg = new System.Windows.Forms.Label();
            this.labelNameReg = new System.Windows.Forms.Label();
            this.textPasswordReg = new System.Windows.Forms.TextBox();
            this.buttonAuthPanel = new System.Windows.Forms.Button();
            this.buttonReg = new System.Windows.Forms.Button();
            this.textMailReg = new System.Windows.Forms.TextBox();
            this.textLoginReg = new System.Windows.Forms.TextBox();
            this.labelReg = new System.Windows.Forms.Label();
            this.panelAuthorization = new System.Windows.Forms.Panel();
            this.labelPassAuth = new System.Windows.Forms.Label();
            this.labelLoginAuth = new System.Windows.Forms.Label();
            this.buttonAuth = new System.Windows.Forms.Button();
            this.buttonRegPanel = new System.Windows.Forms.Button();
            this.textPasswordAuth = new System.Windows.Forms.TextBox();
            this.textLoginAuth = new System.Windows.Forms.TextBox();
            this.labelAuthorization = new System.Windows.Forms.Label();
            this.panelRegistration.SuspendLayout();
            this.panelAuthorization.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelRegistration
            // 
            this.panelRegistration.Controls.Add(this.labelPassReg);
            this.panelRegistration.Controls.Add(this.labelMailReg);
            this.panelRegistration.Controls.Add(this.labelNameReg);
            this.panelRegistration.Controls.Add(this.textPasswordReg);
            this.panelRegistration.Controls.Add(this.buttonAuthPanel);
            this.panelRegistration.Controls.Add(this.buttonReg);
            this.panelRegistration.Controls.Add(this.textMailReg);
            this.panelRegistration.Controls.Add(this.textLoginReg);
            this.panelRegistration.Controls.Add(this.labelReg);
            this.panelRegistration.Location = new System.Drawing.Point(13, 12);
            this.panelRegistration.Name = "panelRegistration";
            this.panelRegistration.Size = new System.Drawing.Size(775, 426);
            this.panelRegistration.TabIndex = 15;
            // 
            // labelPassReg
            // 
            this.labelPassReg.AutoSize = true;
            this.labelPassReg.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.labelPassReg.Location = new System.Drawing.Point(208, 198);
            this.labelPassReg.Name = "labelPassReg";
            this.labelPassReg.Size = new System.Drawing.Size(72, 22);
            this.labelPassReg.TabIndex = 8;
            this.labelPassReg.Text = "Пароль";
            // 
            // labelMailReg
            // 
            this.labelMailReg.AutoSize = true;
            this.labelMailReg.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.labelMailReg.Location = new System.Drawing.Point(189, 153);
            this.labelMailReg.Name = "labelMailReg";
            this.labelMailReg.Size = new System.Drawing.Size(91, 22);
            this.labelMailReg.TabIndex = 7;
            this.labelMailReg.Text = "Эл. почта";
            // 
            // labelNameReg
            // 
            this.labelNameReg.AutoSize = true;
            this.labelNameReg.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.labelNameReg.Location = new System.Drawing.Point(220, 111);
            this.labelNameReg.Name = "labelNameReg";
            this.labelNameReg.Size = new System.Drawing.Size(60, 22);
            this.labelNameReg.TabIndex = 6;
            this.labelNameReg.Text = "Логин";
            // 
            // textPasswordReg
            // 
            this.textPasswordReg.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textPasswordReg.Location = new System.Drawing.Point(285, 193);
            this.textPasswordReg.Name = "textPasswordReg";
            this.textPasswordReg.Size = new System.Drawing.Size(205, 27);
            this.textPasswordReg.TabIndex = 5;
            this.textPasswordReg.UseSystemPasswordChar = true;
            // 
            // buttonAuthPanel
            // 
            this.buttonAuthPanel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonAuthPanel.Location = new System.Drawing.Point(285, 309);
            this.buttonAuthPanel.Name = "buttonAuthPanel";
            this.buttonAuthPanel.Size = new System.Drawing.Size(204, 44);
            this.buttonAuthPanel.TabIndex = 4;
            this.buttonAuthPanel.Text = "Авторизоваться";
            this.buttonAuthPanel.UseVisualStyleBackColor = true;
            this.buttonAuthPanel.Click += new System.EventHandler(this.buttonAuthPanel_Click);
            // 
            // buttonReg
            // 
            this.buttonReg.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonReg.Location = new System.Drawing.Point(286, 259);
            this.buttonReg.Name = "buttonReg";
            this.buttonReg.Size = new System.Drawing.Size(204, 44);
            this.buttonReg.TabIndex = 3;
            this.buttonReg.Text = "Зарегистрироваться";
            this.buttonReg.UseVisualStyleBackColor = true;
            this.buttonReg.Click += new System.EventHandler(this.buttonReg_Click);
            // 
            // textMailReg
            // 
            this.textMailReg.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textMailReg.Location = new System.Drawing.Point(286, 148);
            this.textMailReg.Name = "textMailReg";
            this.textMailReg.Size = new System.Drawing.Size(205, 27);
            this.textMailReg.TabIndex = 2;
            // 
            // textLoginReg
            // 
            this.textLoginReg.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textLoginReg.Location = new System.Drawing.Point(286, 106);
            this.textLoginReg.Name = "textLoginReg";
            this.textLoginReg.Size = new System.Drawing.Size(205, 27);
            this.textLoginReg.TabIndex = 1;
            // 
            // labelReg
            // 
            this.labelReg.AutoSize = true;
            this.labelReg.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelReg.Location = new System.Drawing.Point(320, 29);
            this.labelReg.Name = "labelReg";
            this.labelReg.Size = new System.Drawing.Size(131, 25);
            this.labelReg.TabIndex = 0;
            this.labelReg.Text = "Регистрация";
            // 
            // panelAuthorization
            // 
            this.panelAuthorization.Controls.Add(this.labelPassAuth);
            this.panelAuthorization.Controls.Add(this.labelLoginAuth);
            this.panelAuthorization.Controls.Add(this.buttonAuth);
            this.panelAuthorization.Controls.Add(this.buttonRegPanel);
            this.panelAuthorization.Controls.Add(this.textPasswordAuth);
            this.panelAuthorization.Controls.Add(this.textLoginAuth);
            this.panelAuthorization.Controls.Add(this.labelAuthorization);
            this.panelAuthorization.Enabled = false;
            this.panelAuthorization.Location = new System.Drawing.Point(13, 12);
            this.panelAuthorization.Name = "panelAuthorization";
            this.panelAuthorization.Size = new System.Drawing.Size(775, 426);
            this.panelAuthorization.TabIndex = 16;
            this.panelAuthorization.Visible = false;
            // 
            // labelPassAuth
            // 
            this.labelPassAuth.AutoSize = true;
            this.labelPassAuth.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.labelPassAuth.Location = new System.Drawing.Point(208, 178);
            this.labelPassAuth.Name = "labelPassAuth";
            this.labelPassAuth.Size = new System.Drawing.Size(72, 22);
            this.labelPassAuth.TabIndex = 9;
            this.labelPassAuth.Text = "Пароль";
            // 
            // labelLoginAuth
            // 
            this.labelLoginAuth.AutoSize = true;
            this.labelLoginAuth.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.labelLoginAuth.Location = new System.Drawing.Point(103, 111);
            this.labelLoginAuth.Name = "labelLoginAuth";
            this.labelLoginAuth.Size = new System.Drawing.Size(177, 22);
            this.labelLoginAuth.TabIndex = 8;
            this.labelLoginAuth.Text = "Логин или эл. почта";
            this.labelLoginAuth.Click += new System.EventHandler(this.labelLoginAuth_Click);
            // 
            // buttonAuth
            // 
            this.buttonAuth.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonAuth.Location = new System.Drawing.Point(346, 228);
            this.buttonAuth.Name = "buttonAuth";
            this.buttonAuth.Size = new System.Drawing.Size(95, 44);
            this.buttonAuth.TabIndex = 3;
            this.buttonAuth.Text = "Войти";
            this.buttonAuth.UseVisualStyleBackColor = true;
            this.buttonAuth.Click += new System.EventHandler(this.buttonAuth_Click);
            // 
            // buttonRegPanel
            // 
            this.buttonRegPanel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonRegPanel.Location = new System.Drawing.Point(301, 309);
            this.buttonRegPanel.Name = "buttonRegPanel";
            this.buttonRegPanel.Size = new System.Drawing.Size(190, 61);
            this.buttonRegPanel.TabIndex = 4;
            this.buttonRegPanel.Text = "Нет аккаунта? Зарегистрироваться";
            this.buttonRegPanel.UseVisualStyleBackColor = true;
            this.buttonRegPanel.Click += new System.EventHandler(this.buttonRegPanel_Click);
            // 
            // textPasswordAuth
            // 
            this.textPasswordAuth.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textPasswordAuth.Location = new System.Drawing.Point(286, 173);
            this.textPasswordAuth.Name = "textPasswordAuth";
            this.textPasswordAuth.Size = new System.Drawing.Size(205, 27);
            this.textPasswordAuth.TabIndex = 2;
            this.textPasswordAuth.UseSystemPasswordChar = true;
            // 
            // textLoginAuth
            // 
            this.textLoginAuth.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textLoginAuth.Location = new System.Drawing.Point(286, 106);
            this.textLoginAuth.Name = "textLoginAuth";
            this.textLoginAuth.Size = new System.Drawing.Size(205, 27);
            this.textLoginAuth.TabIndex = 1;
            // 
            // labelAuthorization
            // 
            this.labelAuthorization.AutoSize = true;
            this.labelAuthorization.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelAuthorization.Location = new System.Drawing.Point(320, 29);
            this.labelAuthorization.Name = "labelAuthorization";
            this.labelAuthorization.Size = new System.Drawing.Size(135, 25);
            this.labelAuthorization.TabIndex = 0;
            this.labelAuthorization.Text = "Авторизация";
            // 
            // FormLogging
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panelRegistration);
            this.Controls.Add(this.panelAuthorization);
            this.Name = "FormLogging";
            this.Text = "Авторизация";
            this.Load += new System.EventHandler(this.FormLogging_Load);
            this.panelRegistration.ResumeLayout(false);
            this.panelRegistration.PerformLayout();
            this.panelAuthorization.ResumeLayout(false);
            this.panelAuthorization.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelRegistration;
        private System.Windows.Forms.TextBox textPasswordReg;
        private System.Windows.Forms.Button buttonAuthPanel;
        private System.Windows.Forms.Button buttonReg;
        private System.Windows.Forms.TextBox textMailReg;
        private System.Windows.Forms.TextBox textLoginReg;
        private System.Windows.Forms.Label labelReg;
        private System.Windows.Forms.Panel panelAuthorization;
        private System.Windows.Forms.Button buttonAuth;
        private System.Windows.Forms.Button buttonRegPanel;
        private System.Windows.Forms.TextBox textPasswordAuth;
        private System.Windows.Forms.TextBox textLoginAuth;
        private System.Windows.Forms.Label labelAuthorization;
        private System.Windows.Forms.Label labelMailReg;
        private System.Windows.Forms.Label labelNameReg;
        private System.Windows.Forms.Label labelPassReg;
        private System.Windows.Forms.Label labelPassAuth;
        private System.Windows.Forms.Label labelLoginAuth;
    }
}