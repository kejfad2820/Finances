﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinancesProject
{
    public partial class FormLogging : Form
    {
        static string relativePath = @"..\..\UsersDB.mdf";
        string connectionString = $@"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog = UsersDB.mdf;AttachDbFilename={Path.Combine(AppDomain.CurrentDomain.BaseDirectory, relativePath)};Integrated Security=True";

        public FormLogging()
        {
            InitializeComponent();
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    Debug.Write("Success connection");
                    OpenWindow(panelAuthorization);
                }
                catch (Exception ex)
                {
                    Debug.Write(ex);
                }
            }
        }

        public void OpenWindow(Panel panel)
        {
            panelAuthorization.Visible = false;
            panelAuthorization.Enabled = false;
            panelRegistration.Visible = false;
            panelRegistration.Enabled = false;
            panel.Visible = true;
            panel.Enabled = true;
        }

        public void OpenAccount(int id)
        {
            FormMain f2 = new FormMain();
            this.Hide();
            f2.ShowDialog();
            this.Close();

            f2.id = id;
        }

        public static string Hashing(string data)
        {
            using (SHA256 sha256Hash = SHA256.Create())
            {
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(data));
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                Debug.WriteLine(builder.ToString());
                return builder.ToString();
            }
        }

        public void Registration(string login, string email, string password)
        {
            string loginHashed, emailHashed, passwordHashed;

            if(login != null && email != null && password != null)
            {
                if(login.Length > 6 && email.Length > 6 && password.Length > 6)
                {
                    loginHashed = Hashing(login);
                    emailHashed = Hashing(email);
                    passwordHashed = Hashing(password);

                    using (SqlConnection conn = new SqlConnection(connectionString))
                    {
                        conn.Open();
                        string sql = "SELECT 1 FROM Users WHERE Login = @loginHashed OR Email = @emailHashed";
                        SqlCommand select = new SqlCommand(sql, conn);

                        select.Parameters.AddWithValue("@loginHashed", loginHashed);
                        select.Parameters.AddWithValue("@emailHashed", emailHashed);

                        object row = select.ExecuteScalar();

                        if (row == DBNull.Value || row == null)
                        {
                            string insert = "INSERT INTO Users(Login, Email, Password) " +
                            "VALUES(@loginHashed, @emailHashed, @passwordHashed)";

                            SqlCommand hash = new SqlCommand(insert, conn);

                            hash.Parameters.AddWithValue("@loginHashed", loginHashed);
                            hash.Parameters.AddWithValue("@emailHashed", emailHashed);
                            hash.Parameters.AddWithValue("@passwordHashed", passwordHashed);

                            int row_hashed = hash.ExecuteNonQuery();      

                            MessageBox.Show("Успешная регистрация", "Успешно", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            string id = "SELECT Id FROM Users WHERE Login = @loginHashed";

                            SqlCommand select_id = new SqlCommand(id, conn);

                            select_id.Parameters.AddWithValue("@loginHashed", loginHashed);

                            int row_id = (int)select_id.ExecuteScalar();

                            conn.Close();

                            OpenAccount(row_id);
                        }
                        else
                        {
                            MessageBox.Show("Такой пользователь уже существует", "Неверный ввод", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Длина каждого поля должна быть не менее 6 символов", "Неверный ввод", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Все поля должны быть заполнены", "Неверный ввод", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void Authorization(string login, string password)
        {
            string loginHashed, passwordHashed;

            if(login != null && password != null)
            {
                try
                {
                    using(SqlConnection conn = new SqlConnection(connectionString))
                    {
                        conn.Open();

                        loginHashed = Hashing(login);
                        passwordHashed = Hashing(password);

                        string sql = "SELECT 1 FROM Users WHERE Login = @loginHashed OR Email = @loginHashed";
                        SqlCommand select = new SqlCommand(sql, conn);

                        select.Parameters.AddWithValue("@loginHashed", loginHashed);

                        object row = select.ExecuteScalar();

                        if (row == DBNull.Value || row == null)
                        {
                            MessageBox.Show("Неверный логин", "Неверный ввод", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        else
                        {
                            string sql_pass = "SELECT 1 FROM Users WHERE Password = @passwordHashed";
                            SqlCommand select_pass = new SqlCommand(sql_pass, conn);

                            select_pass.Parameters.AddWithValue("@passwordHashed", passwordHashed);

                            object row_pass = select_pass.ExecuteScalar();

                            if(row_pass == DBNull.Value || row_pass == null)
                            {
                                MessageBox.Show("Неверный пароль", "Неверный ввод", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                            else
                            {
                                MessageBox.Show("Вы успешно авторизовались", "Успешный вход", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                string id = "SELECT Id FROM Users WHERE Login = @loginHashed";

                                SqlCommand select_id = new SqlCommand(id, conn);

                                select_id.Parameters.AddWithValue("@loginHashed", loginHashed);

                                int row_id = (int)select_id.ExecuteScalar();

                                conn.Close();

                                OpenAccount(row_id);
                            }
                        }

                    }
                }
                catch (Exception ex)
                {
                    Debug.WriteLine(ex.Message);
                }
            }
        }



        private void labelLoginAuth_Click(object sender, EventArgs e)
        {

        }

        private void buttonRegPanel_Click(object sender, EventArgs e)
        {
            OpenWindow(panelRegistration);
        }

        private void buttonAuthPanel_Click(object sender, EventArgs e)
        {
            OpenWindow(panelAuthorization);
        }

        private void buttonAuth_Click(object sender, EventArgs e)
        {
            /*if(textLoginAuth.Text == "admin" && textPasswordAuth.Text == "admin")
            {
                FormMain f2 = new FormMain();
                this.Hide();
                f2.ShowDialog();
                this.Close();
            }*/
            Authorization(textLoginAuth.Text, textPasswordAuth.Text);

        }

        private void buttonReg_Click(object sender, EventArgs e)
        {
            Registration(textLoginReg.Text, textMailReg.Text, textPasswordReg.Text);
        }
    }
}
