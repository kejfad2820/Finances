﻿namespace FinancesProject
{
    partial class FormData
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textDescriptionOfWrite = new System.Windows.Forms.TextBox();
            this.textAmountOfWrite = new System.Windows.Forms.TextBox();
            this.labelDateOfWrite = new System.Windows.Forms.Label();
            this.dateOfWrite = new System.Windows.Forms.DateTimePicker();
            this.labelDescriptionOfWrite = new System.Windows.Forms.Label();
            this.labelCategoriesOfWrite = new System.Windows.Forms.Label();
            this.labelAmountOfWrite = new System.Windows.Forms.Label();
            this.labelWalletsOfWrite = new System.Windows.Forms.Label();
            this.comboBoxCategoriesOfWrite = new System.Windows.Forms.ComboBox();
            this.comboBoxWalletsOfWrite = new System.Windows.Forms.ComboBox();
            this.radioButtonExpenseOfWrite = new System.Windows.Forms.RadioButton();
            this.radioButtonIncomeOfWrite = new System.Windows.Forms.RadioButton();
            this.buttonAddWrite = new System.Windows.Forms.Button();
            this.buttonBackData = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textDescriptionOfWrite
            // 
            this.textDescriptionOfWrite.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textDescriptionOfWrite.Location = new System.Drawing.Point(140, 89);
            this.textDescriptionOfWrite.Name = "textDescriptionOfWrite";
            this.textDescriptionOfWrite.Size = new System.Drawing.Size(205, 27);
            this.textDescriptionOfWrite.TabIndex = 3;
            // 
            // textAmountOfWrite
            // 
            this.textAmountOfWrite.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textAmountOfWrite.Location = new System.Drawing.Point(140, 155);
            this.textAmountOfWrite.Name = "textAmountOfWrite";
            this.textAmountOfWrite.Size = new System.Drawing.Size(205, 27);
            this.textAmountOfWrite.TabIndex = 5;
            // 
            // labelDateOfWrite
            // 
            this.labelDateOfWrite.AutoSize = true;
            this.labelDateOfWrite.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.labelDateOfWrite.Location = new System.Drawing.Point(82, 61);
            this.labelDateOfWrite.Name = "labelDateOfWrite";
            this.labelDateOfWrite.Size = new System.Drawing.Size(52, 22);
            this.labelDateOfWrite.TabIndex = 7;
            this.labelDateOfWrite.Text = "Дата";
            // 
            // dateOfWrite
            // 
            this.dateOfWrite.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.dateOfWrite.Location = new System.Drawing.Point(140, 56);
            this.dateOfWrite.Name = "dateOfWrite";
            this.dateOfWrite.Size = new System.Drawing.Size(205, 27);
            this.dateOfWrite.TabIndex = 8;
            // 
            // labelDescriptionOfWrite
            // 
            this.labelDescriptionOfWrite.AutoSize = true;
            this.labelDescriptionOfWrite.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.labelDescriptionOfWrite.Location = new System.Drawing.Point(41, 94);
            this.labelDescriptionOfWrite.Name = "labelDescriptionOfWrite";
            this.labelDescriptionOfWrite.Size = new System.Drawing.Size(93, 22);
            this.labelDescriptionOfWrite.TabIndex = 9;
            this.labelDescriptionOfWrite.Text = "Описание";
            // 
            // labelCategoriesOfWrite
            // 
            this.labelCategoriesOfWrite.AutoSize = true;
            this.labelCategoriesOfWrite.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.labelCategoriesOfWrite.Location = new System.Drawing.Point(37, 127);
            this.labelCategoriesOfWrite.Name = "labelCategoriesOfWrite";
            this.labelCategoriesOfWrite.Size = new System.Drawing.Size(97, 22);
            this.labelCategoriesOfWrite.TabIndex = 10;
            this.labelCategoriesOfWrite.Text = "Категория";
            // 
            // labelAmountOfWrite
            // 
            this.labelAmountOfWrite.AutoSize = true;
            this.labelAmountOfWrite.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.labelAmountOfWrite.Location = new System.Drawing.Point(66, 160);
            this.labelAmountOfWrite.Name = "labelAmountOfWrite";
            this.labelAmountOfWrite.Size = new System.Drawing.Size(68, 22);
            this.labelAmountOfWrite.TabIndex = 11;
            this.labelAmountOfWrite.Text = "Сумма";
            // 
            // labelWalletsOfWrite
            // 
            this.labelWalletsOfWrite.AutoSize = true;
            this.labelWalletsOfWrite.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.labelWalletsOfWrite.Location = new System.Drawing.Point(49, 193);
            this.labelWalletsOfWrite.Name = "labelWalletsOfWrite";
            this.labelWalletsOfWrite.Size = new System.Drawing.Size(85, 22);
            this.labelWalletsOfWrite.TabIndex = 12;
            this.labelWalletsOfWrite.Text = "Кошелек";
            // 
            // comboBoxCategoriesOfWrite
            // 
            this.comboBoxCategoriesOfWrite.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxCategoriesOfWrite.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBoxCategoriesOfWrite.FormattingEnabled = true;
            this.comboBoxCategoriesOfWrite.Location = new System.Drawing.Point(140, 121);
            this.comboBoxCategoriesOfWrite.Name = "comboBoxCategoriesOfWrite";
            this.comboBoxCategoriesOfWrite.Size = new System.Drawing.Size(205, 28);
            this.comboBoxCategoriesOfWrite.TabIndex = 13;
            // 
            // comboBoxWalletsOfWrite
            // 
            this.comboBoxWalletsOfWrite.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxWalletsOfWrite.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBoxWalletsOfWrite.FormattingEnabled = true;
            this.comboBoxWalletsOfWrite.Location = new System.Drawing.Point(140, 187);
            this.comboBoxWalletsOfWrite.Name = "comboBoxWalletsOfWrite";
            this.comboBoxWalletsOfWrite.Size = new System.Drawing.Size(205, 28);
            this.comboBoxWalletsOfWrite.TabIndex = 14;
            // 
            // radioButtonExpenseOfWrite
            // 
            this.radioButtonExpenseOfWrite.AutoSize = true;
            this.radioButtonExpenseOfWrite.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.radioButtonExpenseOfWrite.Location = new System.Drawing.Point(140, 221);
            this.radioButtonExpenseOfWrite.Name = "radioButtonExpenseOfWrite";
            this.radioButtonExpenseOfWrite.Size = new System.Drawing.Size(89, 26);
            this.radioButtonExpenseOfWrite.TabIndex = 15;
            this.radioButtonExpenseOfWrite.TabStop = true;
            this.radioButtonExpenseOfWrite.Text = "Расход";
            this.radioButtonExpenseOfWrite.UseVisualStyleBackColor = true;
            // 
            // radioButtonIncomeOfWrite
            // 
            this.radioButtonIncomeOfWrite.AutoSize = true;
            this.radioButtonIncomeOfWrite.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.radioButtonIncomeOfWrite.Location = new System.Drawing.Point(263, 221);
            this.radioButtonIncomeOfWrite.Name = "radioButtonIncomeOfWrite";
            this.radioButtonIncomeOfWrite.Size = new System.Drawing.Size(82, 26);
            this.radioButtonIncomeOfWrite.TabIndex = 16;
            this.radioButtonIncomeOfWrite.TabStop = true;
            this.radioButtonIncomeOfWrite.Text = "Доход";
            this.radioButtonIncomeOfWrite.UseVisualStyleBackColor = true;
            // 
            // buttonAddWrite
            // 
            this.buttonAddWrite.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonAddWrite.Location = new System.Drawing.Point(194, 253);
            this.buttonAddWrite.Name = "buttonAddWrite";
            this.buttonAddWrite.Size = new System.Drawing.Size(100, 31);
            this.buttonAddWrite.TabIndex = 17;
            this.buttonAddWrite.Text = "Добавить";
            this.buttonAddWrite.UseVisualStyleBackColor = true;
            this.buttonAddWrite.Click += new System.EventHandler(this.buttonAddWrite_Click);
            // 
            // buttonBackData
            // 
            this.buttonBackData.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonBackData.Location = new System.Drawing.Point(372, 318);
            this.buttonBackData.Name = "buttonBackData";
            this.buttonBackData.Size = new System.Drawing.Size(100, 31);
            this.buttonBackData.TabIndex = 18;
            this.buttonBackData.Text = "Назад";
            this.buttonBackData.UseVisualStyleBackColor = true;
            this.buttonBackData.Click += new System.EventHandler(this.buttonBackData_Click);
            // 
            // FormData
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(484, 361);
            this.Controls.Add(this.buttonBackData);
            this.Controls.Add(this.buttonAddWrite);
            this.Controls.Add(this.radioButtonIncomeOfWrite);
            this.Controls.Add(this.radioButtonExpenseOfWrite);
            this.Controls.Add(this.comboBoxWalletsOfWrite);
            this.Controls.Add(this.comboBoxCategoriesOfWrite);
            this.Controls.Add(this.labelWalletsOfWrite);
            this.Controls.Add(this.labelAmountOfWrite);
            this.Controls.Add(this.labelCategoriesOfWrite);
            this.Controls.Add(this.labelDescriptionOfWrite);
            this.Controls.Add(this.dateOfWrite);
            this.Controls.Add(this.labelDateOfWrite);
            this.Controls.Add(this.textAmountOfWrite);
            this.Controls.Add(this.textDescriptionOfWrite);
            this.Name = "FormData";
            this.Text = "Создание транзакции";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox textDescriptionOfWrite;
        private System.Windows.Forms.TextBox textAmountOfWrite;
        private System.Windows.Forms.Label labelDateOfWrite;
        private System.Windows.Forms.DateTimePicker dateOfWrite;
        private System.Windows.Forms.Label labelDescriptionOfWrite;
        private System.Windows.Forms.Label labelCategoriesOfWrite;
        private System.Windows.Forms.Label labelAmountOfWrite;
        private System.Windows.Forms.Label labelWalletsOfWrite;
        private System.Windows.Forms.ComboBox comboBoxCategoriesOfWrite;
        private System.Windows.Forms.ComboBox comboBoxWalletsOfWrite;
        private System.Windows.Forms.RadioButton radioButtonExpenseOfWrite;
        private System.Windows.Forms.RadioButton radioButtonIncomeOfWrite;
        private System.Windows.Forms.Button buttonAddWrite;
        private System.Windows.Forms.Button buttonBackData;
    }
}