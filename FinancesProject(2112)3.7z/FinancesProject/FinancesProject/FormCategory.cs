﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinancesProject
{
    public partial class FormCategory : Form
    {
        public int id;
        static string relativePath = @"..\..\UsersDB.mdf";
        string connectionString = $@"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog = UsersDB.mdf;AttachDbFilename={Path.Combine(AppDomain.CurrentDomain.BaseDirectory, relativePath)};Integrated Security=True";

        public FormCategory()
        {
            InitializeComponent();
        }

        private void FormCategory_Load(object sender, EventArgs e)
        {

        }

        private void buttonAddCategory_Click(object sender, EventArgs e)
        {

        }

        private void buttonBackCategory_Click(object sender, EventArgs e)
        {
            FormMain f2 = new FormMain();
            this.Hide();
            f2.ShowDialog();
            this.Close();
        }

        private void comboBoxTypeOfCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }
    }
}
