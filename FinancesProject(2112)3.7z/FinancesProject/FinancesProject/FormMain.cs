﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Diagnostics.Eventing.Reader;

namespace FinancesProject
{
    public partial class FormMain : Form
    {
        public int id;

        public void OpenWindow(Panel panel)
        {
            panelWallets.Visible = false;
            panelWallets.Enabled = false;
            panelStat.Visible = false;
            panelStat.Enabled = false;
            panelMain.Visible = false;
            panelMain.Enabled = false;
            panelProfile.Enabled = false;
            panelProfile.Visible = false;
            panel.Visible = true;
            panel.Enabled = true;
        }

        public void Authorization(TextBox login, TextBox password)
        {
            if(login.Text == "admin" && password.Text == "admin")
            {
                OpenWindow(panelMain);
            }
        }

        public FormMain()
        {
            InitializeComponent();
            string connectionString = (@"Data Source=(localdb)\MSSQLLocalDB;AttachDbFilename=C:\Users\Степан\source\repos\FinancesProject\FinancesProject\UsersDB.mdf;Initial Catalog=UsersDB;Integrated Security=True");
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    Debug.WriteLine("Success connection");
                    OpenWindow(panelMain);
                }
                catch (SqlException ex)
                {
                    Debug.WriteLine(ex.Message);
                }
            }
        }

        private void buttonProfile_Click(object sender, EventArgs e)
        {
            OpenWindow(panelProfile);
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void buttonMain_Click(object sender, EventArgs e)
        {
            OpenWindow(panelMain);
        }

        private void buttonExpenses_Click(object sender, EventArgs e)
        {
            
        }

        private void buttonIncomes_Click(object sender, EventArgs e)
        {
            
        }

        private void buttonStat_Click(object sender, EventArgs e)
        {
            OpenWindow(panelStat);
        }

        private void buttonWallets_Click(object sender, EventArgs e)
        {
            OpenWindow(panelWallets);
        }

        private void panelMain_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panelExpenses_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Expense1_Enter(object sender, EventArgs e)
        {

        }

        private void buttonAddExpense_Click(object sender, EventArgs e)
        {

        }

        private void panelIncomes_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Income1_Enter(object sender, EventArgs e)
        {

        }

        private void buttonAddIncome_Click(object sender, EventArgs e)
        {

        }

        private void panelWallets_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Wallet1_Enter(object sender, EventArgs e)
        {

        }

        private void panelStat_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void buttonAddTransaction_Click(object sender, EventArgs e)
        {
            FormData f3 = new FormData();
            this.Hide();
            f3.ShowDialog();
            this.Close();
            f3.id = id;
        }

        private void buttonAddCategory_Click(object sender, EventArgs e)
        {
            FormCategory f4 = new FormCategory();
            this.Hide();
            f4.ShowDialog();
            this.Close();
            f4.id = id;
        }

        private void buttonAddWallet_Click(object sender, EventArgs e)
        {
            FormWallet f5 = new FormWallet();
            this.Hide();
            f5.ShowDialog();
            this.Close();
            f5.id = id;
        }
    }
}
