﻿namespace FinancesProject
{
    partial class FormCategory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonBackCategory = new System.Windows.Forms.Button();
            this.buttonAddCategory = new System.Windows.Forms.Button();
            this.labelTypeOfCategory = new System.Windows.Forms.Label();
            this.labelNameOfCategory = new System.Windows.Forms.Label();
            this.textNameOfCategory = new System.Windows.Forms.TextBox();
            this.comboBoxTypeOfCategory = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // buttonBackCategory
            // 
            this.buttonBackCategory.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonBackCategory.Location = new System.Drawing.Point(380, 326);
            this.buttonBackCategory.Name = "buttonBackCategory";
            this.buttonBackCategory.Size = new System.Drawing.Size(100, 31);
            this.buttonBackCategory.TabIndex = 38;
            this.buttonBackCategory.Text = "Назад";
            this.buttonBackCategory.UseVisualStyleBackColor = true;
            this.buttonBackCategory.Click += new System.EventHandler(this.buttonBackCategory_Click);
            // 
            // buttonAddCategory
            // 
            this.buttonAddCategory.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonAddCategory.Location = new System.Drawing.Point(194, 210);
            this.buttonAddCategory.Name = "buttonAddCategory";
            this.buttonAddCategory.Size = new System.Drawing.Size(100, 31);
            this.buttonAddCategory.TabIndex = 37;
            this.buttonAddCategory.Text = "Добавить";
            this.buttonAddCategory.UseVisualStyleBackColor = true;
            this.buttonAddCategory.Click += new System.EventHandler(this.buttonAddCategory_Click);
            // 
            // labelTypeOfCategory
            // 
            this.labelTypeOfCategory.AutoSize = true;
            this.labelTypeOfCategory.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.labelTypeOfCategory.Location = new System.Drawing.Point(100, 141);
            this.labelTypeOfCategory.Name = "labelTypeOfCategory";
            this.labelTypeOfCategory.Size = new System.Drawing.Size(42, 22);
            this.labelTypeOfCategory.TabIndex = 36;
            this.labelTypeOfCategory.Text = "Тип";
            // 
            // labelNameOfCategory
            // 
            this.labelNameOfCategory.AutoSize = true;
            this.labelNameOfCategory.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.labelNameOfCategory.Location = new System.Drawing.Point(50, 102);
            this.labelNameOfCategory.Name = "labelNameOfCategory";
            this.labelNameOfCategory.Size = new System.Drawing.Size(92, 22);
            this.labelNameOfCategory.TabIndex = 35;
            this.labelNameOfCategory.Text = "Название";
            // 
            // textNameOfCategory
            // 
            this.textNameOfCategory.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textNameOfCategory.Location = new System.Drawing.Point(148, 97);
            this.textNameOfCategory.Name = "textNameOfCategory";
            this.textNameOfCategory.Size = new System.Drawing.Size(205, 27);
            this.textNameOfCategory.TabIndex = 33;
            // 
            // comboBoxTypeOfCategory
            // 
            this.comboBoxTypeOfCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxTypeOfCategory.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBoxTypeOfCategory.FormattingEnabled = true;
            this.comboBoxTypeOfCategory.Items.AddRange(new object[] {
            "Доход",
            "Расход"});
            this.comboBoxTypeOfCategory.Location = new System.Drawing.Point(148, 135);
            this.comboBoxTypeOfCategory.Name = "comboBoxTypeOfCategory";
            this.comboBoxTypeOfCategory.Size = new System.Drawing.Size(205, 28);
            this.comboBoxTypeOfCategory.TabIndex = 39;
            this.comboBoxTypeOfCategory.SelectedIndexChanged += new System.EventHandler(this.comboBoxTypeOfCategory_SelectedIndexChanged);
            // 
            // FormCategory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(484, 361);
            this.Controls.Add(this.comboBoxTypeOfCategory);
            this.Controls.Add(this.buttonBackCategory);
            this.Controls.Add(this.buttonAddCategory);
            this.Controls.Add(this.labelTypeOfCategory);
            this.Controls.Add(this.labelNameOfCategory);
            this.Controls.Add(this.textNameOfCategory);
            this.Name = "FormCategory";
            this.Text = "Создание категории";
            this.Load += new System.EventHandler(this.FormCategory_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonBackCategory;
        private System.Windows.Forms.Button buttonAddCategory;
        private System.Windows.Forms.Label labelTypeOfCategory;
        private System.Windows.Forms.Label labelNameOfCategory;
        private System.Windows.Forms.TextBox textNameOfCategory;
        private System.Windows.Forms.ComboBox comboBoxTypeOfCategory;
    }
}